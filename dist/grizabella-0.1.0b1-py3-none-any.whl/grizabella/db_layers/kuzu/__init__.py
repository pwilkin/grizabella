# Grizabella Kuzu adapter module
