"""Main window for the Grizabella application.
Handles the overall UI structure, including menus, views, and client interaction.
"""

import sys
from typing import TYPE_CHECKING, Optional

from PySide6.QtCore import Slot
from PySide6.QtWidgets import QApplication, QMainWindow, QMenuBar, QStackedWidget, QTabWidget

from grizabella.ui.views.connection_view import ConnectionView
from grizabella.ui.views.embedding_definition_view import EmbeddingDefinitionView
from grizabella.ui.views.object_explorer_view import ObjectExplorerView
from grizabella.ui.views.object_type_view import ObjectTypeView
from grizabella.ui.views.query_view import QueryView  # Added import
from grizabella.ui.views.relation_explorer_view import RelationExplorerView
from grizabella.ui.views.relation_type_view import RelationTypeView

if TYPE_CHECKING:
    from grizabella.api.client import (
        Grizabella,
    )  # Assuming Grizabella is the client class name


class MainWindow(QMainWindow):
    """Main window for the Grizabella application.
    It will contain the menu bar, toolbar, status bar, and central widget area.
    """

    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("Grizabella - Tri-Layer Memory System")
        self.setGeometry(100, 100, 1200, 800)
        self.grizabella_client: Optional[Grizabella] = None
        self.connection_view: Optional[ConnectionView] = None

        # Schema Editor related views
        self.object_type_view: Optional[ObjectTypeView] = None
        self.embedding_definition_view: Optional[EmbeddingDefinitionView] = None
        self.relation_type_view: Optional[RelationTypeView] = None
        self.schema_editor_tabs: Optional[QTabWidget] = None

        # Object Explorer view
        self.object_explorer_view: Optional[ObjectExplorerView] = None
        # Relation Explorer view
        self.relation_explorer_view: Optional[RelationExplorerView] = None
        # Query View
        self.query_view: Optional[QueryView] = None

        # Main application tabs (to hold Schema Editor and Object Explorer)
        self.main_application_tabs: Optional[QTabWidget] = None

        self.central_stacked_widget: Optional[QStackedWidget] = None

        self._create_menu_bar()
        self._create_status_bar()
        self._setup_central_widget()

    def _create_menu_bar(self) -> None:
        """Creates the main menu bar."""
        menu_bar = self.menuBar()
        if not isinstance(menu_bar, QMenuBar):
            menu_bar = QMenuBar(self)
            self.setMenuBar(menu_bar)

        file_menu = menu_bar.addMenu("&File")
        exit_action = file_menu.addAction("Exit")
        exit_action.triggered.connect(self.close)

        # Placeholder for other menus
        # view_menu = menu_bar.addMenu("&View")
        # view_menu.addAction("Object Types", self._show_object_type_view_action) # Example

    # def _show_object_type_view_action(self):
    #     if self.grizabella_client and self.central_stacked_widget and self.object_type_view:
    #         self.central_stacked_widget.setCurrentWidget(self.object_type_view)
    #     elif not self.grizabella_client:
    #         self.show_status_message("Please connect to a Grizabella instance first.")
    #     else: # Should not happen if UI is consistent
    #         self.show_status_message("Object Type View not available.")

    def _create_status_bar(self) -> None:
        """Creates the status bar."""
        self.status_bar = self.statusBar()
        self.show_status_message("Ready")

    def _setup_central_widget(self) -> None:
        """Sets up the central widget using a QStackedWidget to switch views."""
        self.central_stacked_widget = QStackedWidget(self)

        self.connection_view = ConnectionView(self)
        self.central_stacked_widget.addWidget(self.connection_view)

        # ObjectTypeView is created when a client connects
        # self.object_type_view = ObjectTypeView(None, self) # Initialize with no client
        # self.central_stacked_widget.addWidget(self.object_type_view)

        self.setCentralWidget(self.central_stacked_widget)
        self.central_stacked_widget.setCurrentWidget(self.connection_view)

        if self.connection_view:
            self.connection_view.connection_status_updated.connect(
                self.show_status_message,
            )
            self.connection_view.grizabella_client_updated.connect(
                self.set_grizabella_client,
            )

    @Slot(str)
    def show_status_message(self, message: str) -> None:
        """Displays a message in the status bar."""
        if hasattr(self, "status_bar") and self.status_bar:
            self.status_bar.showMessage(message)
        else:
            pass

    @Slot(object)
    def set_grizabella_client(
        self, client: Optional["Grizabella"],
    ) -> None:  # Corrected type hint
        """Stores the Grizabella client instance and updates status and central view."""
        self.grizabella_client = client
        if client and self.central_stacked_widget:
            db_identifier = getattr(
                client, "db_path", getattr(client, "db_name_or_path", "Unknown DB"),
            )
            self.show_status_message(f"Grizabella client connected: {db_identifier}")

            if not self.main_application_tabs:
                self.main_application_tabs = QTabWidget()
                self.central_stacked_widget.addWidget(self.main_application_tabs)

                # 1. Schema Editor Tab (as a QTabWidget itself)
                self.schema_editor_tabs = QTabWidget()
                self.main_application_tabs.addTab(
                    self.schema_editor_tabs, "Schema Editor",
                )

                # Populate Schema Editor Tabs
                self.object_type_view = ObjectTypeView(self.grizabella_client, self)
                self.schema_editor_tabs.addTab(self.object_type_view, "Object Types")

                self.embedding_definition_view = EmbeddingDefinitionView(
                    self.grizabella_client, self,
                )
                self.schema_editor_tabs.addTab(
                    self.embedding_definition_view, "Embedding Definitions",
                )

                self.relation_type_view = RelationTypeView(self.grizabella_client, self)
                self.schema_editor_tabs.addTab(
                    self.relation_type_view, "Relation Types",
                )

                # 2. Object Explorer Tab
                if self.grizabella_client:  # Ensure client is not None
                    self.object_explorer_view = ObjectExplorerView(
                        self.grizabella_client, self,
                    )
                    self.main_application_tabs.addTab(
                        self.object_explorer_view, "Object Explorer",
                    )
                    # Connect busy signal from object explorer to status bar
                    if hasattr(self.object_explorer_view, "busy_signal"):
                        self.object_explorer_view.busy_signal.connect(
                            lambda busy: self.show_status_message(
                                "Processing..." if busy else "Ready",
                            ),
                        )
                else:
                    # This case should ideally not be reached if client is guaranteed by the if block
                    # However, as a fallback, create it without a client or show an error
                    self.object_explorer_view = ObjectExplorerView(None, self)  # type: ignore
                    self.object_explorer_view.setEnabled(False)  # Disable if no client
                    self.main_application_tabs.addTab(
                        self.object_explorer_view, "Object Explorer (No Client)",
                    )

                # 3. Relation Explorer Tab
                if self.grizabella_client:
                    self.relation_explorer_view = RelationExplorerView(
                        self.grizabella_client, self,
                    )
                    self.main_application_tabs.addTab(
                        self.relation_explorer_view, "Relation Explorer",
                    )
                    # RelationExplorerView manages its own busy state internally for now
                    # If a generic busy_signal is added later, it can be connected here.
                else:
                    self.relation_explorer_view = RelationExplorerView(None, self)  # type: ignore
                    self.relation_explorer_view.setEnabled(False)
                    self.main_application_tabs.addTab(
                        self.relation_explorer_view, "Relation Explorer (No Client)",
                    )

                # 4. Query View Tab
                if self.grizabella_client:
                    self.query_view = QueryView(self.grizabella_client, self)
                    self.main_application_tabs.addTab(self.query_view, "Query Builder")
                    # QueryView manages its own busy state and error popups
                else:
                    self.query_view = QueryView(None, self)  # type: ignore
                    self.query_view.setEnabled(False)
                    self.main_application_tabs.addTab(
                        self.query_view, "Query Builder (No Client)",
                    )

            else:
                # Client reconnected or already connected, ensure all views have the client
                if self.object_type_view:
                    self.object_type_view.set_client(
                        self.grizabella_client,
                    )  # Handles Optional client
                    if self.grizabella_client:
                        self.object_type_view.refresh_object_types()
                if self.embedding_definition_view:
                    if hasattr(self.embedding_definition_view, "set_grizabella_client"):
                        self.embedding_definition_view.set_grizabella_client(
                            self.grizabella_client,
                        )
                    if self.grizabella_client and hasattr(
                        self.embedding_definition_view, "refresh_definitions",
                    ):
                        self.embedding_definition_view.refresh_definitions()
                if self.relation_type_view:
                    if hasattr(self.relation_type_view, "set_grizabella_client"):
                        self.relation_type_view.set_grizabella_client(
                            self.grizabella_client,
                        )
                    if self.grizabella_client and hasattr(
                        self.relation_type_view, "refresh_relation_types",
                    ):
                        self.relation_type_view.refresh_relation_types()
                if self.object_explorer_view and hasattr(self.object_explorer_view, "set_client"):
                    self.object_explorer_view.set_client(self.grizabella_client)
                    # refresh_view_data is called by set_client if client is not None
                if self.relation_explorer_view:
                    if hasattr(
                        self.relation_explorer_view, "grizabella_client",
                    ):  # Direct attribute set
                        self.relation_explorer_view.grizabella_client = (
                            self.grizabella_client
                        )
                    if self.grizabella_client and hasattr(
                        self.relation_explorer_view, "refresh_view",
                    ):
                        self.relation_explorer_view.refresh_view()
                if self.query_view:
                    self.query_view.set_client(
                        self.grizabella_client,
                    )  # Use set_client method
                    # _load_initial_data and setEnabled are handled by set_client

            self.central_stacked_widget.setCurrentWidget(self.main_application_tabs)

        elif self.central_stacked_widget:  # Client is None (disconnected)
            self.show_status_message(
                "Grizabella client disconnected or connection failed.",
            )
            # Clear client from all views
            if self.object_type_view:
                self.object_type_view.set_client(None)
            if self.embedding_definition_view and hasattr(
                self.embedding_definition_view, "set_grizabella_client",
            ):
                self.embedding_definition_view.set_grizabella_client(None)
            # Add manual clear for embedding_definition_view if no set_grizabella_client
            elif self.embedding_definition_view and hasattr(
                self.embedding_definition_view, "definitions_list_widget",
            ):
                self.embedding_definition_view.definitions_list_widget.clear()
                self.embedding_definition_view.details_text_edit.clear()
                self.embedding_definition_view.current_definitions = []

            if self.relation_type_view and hasattr(
                self.relation_type_view, "set_grizabella_client",
            ):
                self.relation_type_view.set_grizabella_client(None)
            # The set_grizabella_client(None) call in RelationTypeView already handles
            # clearing its UI elements, including calling its own _clear_details.
            # The following elif block for manual clearing is redundant and causes W0212.
            # elif self.relation_type_view and hasattr(self.relation_type_view, 'list_widget'):
            #     self.relation_type_view.list_widget.clear()
            #     self.relation_type_view.list_widget.addItem("Client disconnected.")
            #     self.relation_type_view.list_widget.setEnabled(False)
            #     if hasattr(self.relation_type_view, '_clear_details'):
            #         self.relation_type_view._clear_details()
            #     self.relation_type_view.new_button.setEnabled(False)
            #     self.relation_type_view.edit_button.setEnabled(False)
            #     self.relation_type_view.delete_button.setEnabled(False)

            if self.object_explorer_view and hasattr(self.object_explorer_view, "set_client"):
                self.object_explorer_view.set_client(
                    None,
                )  # set_client handles UI update for None
            if self.relation_explorer_view:
                if hasattr(self.relation_explorer_view, "grizabella_client"):
                    self.relation_explorer_view.grizabella_client = None
                if hasattr(
                    self.relation_explorer_view, "refresh_view",
                ):  # To clear views
                    self.relation_explorer_view.refresh_view()
                if self.relation_explorer_view:
                    self.relation_explorer_view.setEnabled(False)

            if self.query_view:
                self.query_view.set_client(None)  # Use set_client method
                # Clearing data and setEnabled is handled by set_client(None)

            if self.connection_view:
                self.central_stacked_widget.setCurrentWidget(self.connection_view)

    def get_grizabella_client(self) -> Optional["Grizabella"]:  # Corrected type hint
        """Returns the stored Grizabella client instance."""
        return self.grizabella_client


if __name__ == "__main__":
    app = QApplication(sys.argv)
    main_win = MainWindow()
    main_win.show()
    sys.exit(app.exec())
