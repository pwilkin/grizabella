"""QWidget for exploring Object Instances in Grizabella."""
# Standard library imports
import sys
import uuid
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path
from typing import Any, Optional, Union

from PySide6.QtCore import QThread, Signal, Slot  # QModelIndex removed as unused
from PySide6.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QComboBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QMessageBox,
    QPushButton,
    QTableView,
    QVBoxLayout,
    QWidget,
)

from grizabella.api.client import Grizabella
from grizabella.core.models import (
    ObjectInstance,
    ObjectTypeDefinition,
    PropertyDataType,
    PropertyDefinition,
    RelationInstance,
)  # Added RelationInstance
from grizabella.ui.dialogs.object_instance_dialog import ObjectInstanceDialog

# First-party imports
from grizabella.ui.models.object_instance_table_model import ObjectInstanceTableModel


# --- Worker Threads ---
class LoadObjectTypesWorker(QThread):
    """Worker thread to load object types."""

    finished = Signal(list)  # List[ObjectTypeDefinition]
    error = Signal(str)

    def __init__(self, client: Grizabella) -> None:
        super().__init__()
        self.client = client

    def run(self) -> None:
        try:
            types = self.client.list_object_types()
            self.finished.emit(types if types else [])
        except Exception as e:
            self.error.emit(f"Failed to load object types: {e}")


class LoadObjectInstancesWorker(QThread):
    """Worker thread to load object instances."""

    finished = Signal(list)  # List[ObjectInstance]
    error = Signal(str)

    def __init__(self, client: Grizabella, object_type_name: str) -> None:
        super().__init__()
        self.client = client
        self.object_type_name = object_type_name

    def run(self) -> None:
        try:
            # In a real app, consider pagination/limits
            instances = self.client.find_objects(
                type_name=self.object_type_name, filter_criteria={},
            )
            self.finished.emit(instances if instances else [])
        except Exception as e:
            self.error.emit(
                f"Failed to load instances for '{self.object_type_name}': {e}",
            )


class DeleteObjectWorker(QThread):
    """Worker thread to delete an object instance."""

    finished = Signal(str, str)  # object_type_name, object_id (UUID as str)
    error = Signal(str)

    def __init__(self, client: Grizabella, object_type_name: str, object_id: uuid.UUID) -> None:
        super().__init__()
        self.client = client
        self.object_type_name = object_type_name
        self.object_id = object_id

    def run(self) -> None:
        try:
            # Client's delete_object expects object_id as str
            self.client.delete_object(
                object_id=str(self.object_id), type_name=self.object_type_name,
            )
            self.finished.emit(self.object_type_name, str(self.object_id))
        except Exception as e:
            self.error.emit(f"Failed to delete object '{self.object_id}': {e}")


class ObjectExplorerView(QWidget):
    """View for exploring and managing Object Instances."""

    busy_signal = Signal(bool)
    refresh_instances_signal = Signal(str)

    def __init__(
        self,
        grizabella_client: Optional[Grizabella],  # Allow None
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.grizabella_client = grizabella_client
        self.current_object_type: Optional[ObjectTypeDefinition] = None
        self.object_instance_model: Optional[ObjectInstanceTableModel] = None

        self.load_types_worker: Optional[LoadObjectTypesWorker] = None
        self.load_instances_worker: Optional[LoadObjectInstancesWorker] = None
        self.delete_worker: Optional[DeleteObjectWorker] = None

        self.setWindowTitle("Object Explorer")
        self._init_ui()
        self._connect_signals()
        if self.grizabella_client:
            self.refresh_view_data()
        else:
            self._handle_no_client()

    def set_client(self, client: Optional[Grizabella]) -> None:
        """Sets or updates the Grizabella client for the view."""
        self.grizabella_client = client
        if client:
            self.refresh_view_data()
        else:
            self._handle_no_client()

    def _handle_no_client(self) -> None:
        """Handles UI state when no client is available."""
        self.object_type_combo.clear()
        self.object_type_combo.setEnabled(False)
        if self.object_instance_model:
            self.object_instance_model.clear_data()
        self.current_object_type = None
        self.setWindowTitle("Object Explorer (No Client)")
        self._update_action_buttons_state()

    def _init_ui(self) -> None:
        layout = QVBoxLayout(self)
        selection_layout = QHBoxLayout()
        self.object_type_label = QLabel("Object Type:")
        self.object_type_combo = QComboBox()
        self.object_type_combo.setPlaceholderText("Select Object Type")
        selection_layout.addWidget(self.object_type_label)
        selection_layout.addWidget(self.object_type_combo)
        selection_layout.addStretch()
        layout.addLayout(selection_layout)

        self.instances_table_view = QTableView()
        self.instances_table_view.setSelectionBehavior(
            QAbstractItemView.SelectionBehavior.SelectRows,
        )
        self.instances_table_view.setSelectionMode(
            QAbstractItemView.SelectionMode.SingleSelection,
        )
        self.instances_table_view.horizontalHeader().setStretchLastSection(True)
        self.instances_table_view.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.Interactive,
        )
        self.instances_table_view.setSortingEnabled(True)
        layout.addWidget(self.instances_table_view)

        buttons_layout = QHBoxLayout()
        self.new_object_button = QPushButton("New Object")
        self.view_edit_button = QPushButton("View/Edit Selected")
        self.delete_button = QPushButton("Delete Selected")
        self.refresh_button = QPushButton("Refresh List")
        buttons_layout.addWidget(self.new_object_button)
        buttons_layout.addWidget(self.view_edit_button)
        buttons_layout.addWidget(self.delete_button)
        buttons_layout.addStretch()
        buttons_layout.addWidget(self.refresh_button)
        layout.addLayout(buttons_layout)
        self._update_action_buttons_state()

    def _connect_signals(self) -> None:
        self.object_type_combo.currentIndexChanged.connect(
            self._on_object_type_selected,
        )
        self.new_object_button.clicked.connect(self._on_new_object)
        self.view_edit_button.clicked.connect(self._on_view_edit_object)
        self.delete_button.clicked.connect(self._on_delete_object)
        self.refresh_button.clicked.connect(self._on_refresh_list)
        selection_model = self.instances_table_view.selectionModel()
        if selection_model:
            selection_model.selectionChanged.connect(
                self._on_instance_selection_changed,
            )
        self.refresh_instances_signal.connect(self._load_object_instances)
        self.busy_signal.connect(self._handle_busy_state)

    @Slot(bool)
    def _handle_busy_state(self, busy: bool) -> None:
        self.setEnabled(not busy)  # Disable entire view while busy

    @Slot(list)
    def _on_object_types_loaded(self, object_types: list[ObjectTypeDefinition]) -> None:
        self.busy_signal.emit(False)
        self.object_type_combo.clear()
        if object_types:
            self.object_type_combo.addItem("Select Object Type", userData=None)
            for obj_type in sorted(object_types, key=lambda x: x.name):
                self.object_type_combo.addItem(obj_type.name, userData=obj_type)
            self.object_type_combo.setEnabled(True)
        else:
            self.object_type_combo.addItem("No object types found", userData=None)
            self.object_type_combo.setEnabled(False)
            QMessageBox.information(
                self, "Object Types", "No object types found in the database.",
            )
        self._update_action_buttons_state()

    @Slot(str)
    def _on_object_types_load_error(self, error_message: str) -> None:
        self.busy_signal.emit(False)
        self.object_type_combo.setEnabled(False)
        QMessageBox.critical(self, "Error Loading Object Types", error_message)
        self._update_action_buttons_state()

    def _load_object_types(self) -> None:
        if not self.grizabella_client:
            self._on_object_types_load_error("Client not available.")
            return
        self.busy_signal.emit(True)
        self.object_type_combo.setEnabled(False)
        self.load_types_worker = LoadObjectTypesWorker(self.grizabella_client)
        self.load_types_worker.finished.connect(self._on_object_types_loaded)
        self.load_types_worker.error.connect(self._on_object_types_load_error)
        self.load_types_worker.start()

    @Slot(int)
    def _on_object_type_selected(self, index: int) -> None:
        selected_data = self.object_type_combo.itemData(index)
        if isinstance(selected_data, ObjectTypeDefinition):
            self.current_object_type = selected_data
            self.setWindowTitle(f"Object Explorer - {self.current_object_type.name}")
            self._load_object_instances(self.current_object_type.name)
        else:
            self.current_object_type = None
            if self.object_instance_model:
                self.object_instance_model.clear_data()
            self.setWindowTitle("Object Explorer")
        self._update_action_buttons_state()

    @Slot(str)
    def _load_object_instances(self, object_type_name: str) -> None:
        if not self.current_object_type or not self.grizabella_client:
            self._on_object_instances_load_error(
                "Cannot load instances: No object type selected or client not available.",
            )
            return
        self.busy_signal.emit(True)
        self.instances_table_view.setEnabled(False)

        property_defs_for_table = self._get_properties_for_table(
            self.current_object_type.properties,
        )

        if self.object_instance_model is None:
            self.object_instance_model = ObjectInstanceTableModel(
                property_defs_for_table, parent=self,
            )
            self.instances_table_view.setModel(self.object_instance_model)
        else:
            self.object_instance_model.update_property_definitions(
                property_defs_for_table,
            )

        self.load_instances_worker = LoadObjectInstancesWorker(
            self.grizabella_client, object_type_name,
        )
        self.load_instances_worker.finished.connect(self._on_object_instances_loaded)
        self.load_instances_worker.error.connect(self._on_object_instances_load_error)
        self.load_instances_worker.start()

    def _get_properties_for_table(
        self, all_properties: list[PropertyDefinition],
    ) -> list[PropertyDefinition]:
        props_to_display: list[PropertyDefinition] = []
        # 'id' is not in properties list, it's on MemoryInstance
        id_prop = next((p for p in all_properties if p.name == "id"), None)

        # Create a mock PropertyDefinition for 'id' for table display
        if not id_prop:  # If 'id' is not explicitly in properties, add a representation
            # This assumes 'id' is always a UUID string for display purposes.
            # The actual 'id' comes from ObjectInstance.id
            mock_id_prop = PropertyDefinition(
                name="id",
                data_type=PropertyDataType.UUID,
                is_nullable=False,
                description="Instance ID",
            )
            props_to_display.append(mock_id_prop)

        count = 0
        simple_types = [
            PropertyDataType.TEXT,
            PropertyDataType.INTEGER,
            PropertyDataType.FLOAT,
            PropertyDataType.BOOLEAN,
            PropertyDataType.UUID,
            PropertyDataType.DATETIME,
        ]
        for prop_def in sorted(all_properties, key=lambda p: p.name):
            if prop_def.name == "id":  # Already handled or will be by mock
                continue
            if prop_def.data_type in simple_types and prop_def not in props_to_display:
                props_to_display.append(prop_def)
                count += 1
            if count >= 4:  # Show id + up to 4 other simple properties
                break
        return props_to_display

    @Slot(list)
    def _on_object_instances_loaded(self, instances: list[ObjectInstance]) -> None:
        self.busy_signal.emit(False)
        self.instances_table_view.setEnabled(True)
        if self.object_instance_model:
            self.object_instance_model.set_instances(instances)
        self._update_action_buttons_state()
        if not instances and self.current_object_type:
            QMessageBox.information(
                self,
                "Object Instances",
                f"No instances found for type '{self.current_object_type.name}'.",
            )

    @Slot(str)
    def _on_object_instances_load_error(self, error_message: str) -> None:
        self.busy_signal.emit(False)
        self.instances_table_view.setEnabled(True)
        if self.object_instance_model:
            self.object_instance_model.clear_data()
        QMessageBox.critical(self, "Error Loading Object Instances", error_message)
        self._update_action_buttons_state()

    @Slot()
    def _on_instance_selection_changed(self) -> None:
        self._update_action_buttons_state()

    def _update_action_buttons_state(self) -> None:
        has_type_selected = self.current_object_type is not None
        has_instance_selected = False
        selection_model = self.instances_table_view.selectionModel()
        if selection_model:  # Check if selection model exists
            has_instance_selected = bool(selection_model.selectedRows())

        self.new_object_button.setEnabled(has_type_selected)
        self.view_edit_button.setEnabled(has_type_selected and has_instance_selected)
        self.delete_button.setEnabled(has_type_selected and has_instance_selected)
        self.refresh_button.setEnabled(has_type_selected)

    def _on_new_object(self) -> None:
        if not self.current_object_type:
            QMessageBox.warning(
                self, "New Object", "Please select an object type first.",
            )
            return
        if not self.grizabella_client:
            QMessageBox.critical(
                self, "Client Error", "Grizabella client is not available.",
            )
            return

        dialog = ObjectInstanceDialog(
            grizabella_client=self.grizabella_client,
            object_type=self.current_object_type,
            mode="create",
            parent=self,
        )
        dialog.instance_upserted_signal.connect(
            lambda _obj_id: self.refresh_instances_signal.emit(
                self.current_object_type.name if self.current_object_type else "",
            ),
        )
        dialog.exec()

    def _on_view_edit_object(self) -> None:
        if not self.current_object_type or not self.object_instance_model:
            return
        if not self.grizabella_client:
            QMessageBox.critical(
                self, "Client Error", "Grizabella client is not available.",
            )
            return

        selected_indexes = self.instances_table_view.selectionModel().selectedRows()
        if not selected_indexes:
            QMessageBox.information(
                self, "View/Edit Object", "Please select an object instance.",
            )
            return

        instance_to_edit = self.object_instance_model.get_instance_at_row(
            selected_indexes[0].row(),
        )
        if not instance_to_edit:
            QMessageBox.critical(
                self, "Error", "Could not retrieve selected instance data.",
            )
            return

        dialog = ObjectInstanceDialog(
            grizabella_client=self.grizabella_client,
            object_type=self.current_object_type,
            instance_data=instance_to_edit,
            mode="edit",
            parent=self,
        )
        dialog.instance_upserted_signal.connect(
            lambda _obj_id: self.refresh_instances_signal.emit(
                self.current_object_type.name if self.current_object_type else "",
            ),
        )
        dialog.exec()

    def _on_delete_object(self) -> None:
        if not self.current_object_type or not self.object_instance_model:
            return
        if not self.grizabella_client:
            QMessageBox.critical(
                self, "Client Error", "Grizabella client is not available.",
            )
            return

        selected_indexes = self.instances_table_view.selectionModel().selectedRows()
        if not selected_indexes:
            QMessageBox.information(
                self, "Delete Object", "Please select an object instance to delete.",
            )
            return

        instance_to_delete = self.object_instance_model.get_instance_at_row(
            selected_indexes[0].row(),
        )
        if not instance_to_delete:
            QMessageBox.critical(
                self, "Error", "Could not retrieve instance data for deletion.",
            )
            return

        reply = QMessageBox.question(
            self,
            "Confirm Deletion",
            f"Delete object '{instance_to_delete.id}' of type "
            f"'{self.current_object_type.name}'?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if reply == QMessageBox.StandardButton.Yes:
            self.busy_signal.emit(True)
            self.delete_worker = DeleteObjectWorker(
                self.grizabella_client,
                self.current_object_type.name,
                instance_to_delete.id,
            )
            self.delete_worker.finished.connect(self._on_object_deleted_success)
            self.delete_worker.error.connect(self._on_object_delete_error)
            self.delete_worker.start()

    @Slot(str, str)
    def _on_object_deleted_success(self, object_type_name: str, object_id: str) -> None:
        self.busy_signal.emit(False)
        QMessageBox.information(
            self, "Success", f"Object '{object_id}' deleted successfully.",
        )
        self.refresh_instances_signal.emit(object_type_name)

    @Slot(str)
    def _on_object_delete_error(self, error_message: str) -> None:
        self.busy_signal.emit(False)
        QMessageBox.critical(self, "Error Deleting Object", error_message)

    def _on_refresh_list(self) -> None:
        if self.current_object_type:
            self._load_object_instances(self.current_object_type.name)
        else:
            QMessageBox.information(
                self, "Refresh", "Please select an object type first.",
            )

    def refresh_view_data(self) -> None:
        self._load_object_types()
        if self.object_instance_model:
            self.object_instance_model.clear_data()
        self._update_action_buttons_state()


# --- Mocking for standalone testing ---
class MockGrizabella(Grizabella):
    """Mock Grizabella client for standalone testing."""

    def __init__(
        self,
        db_name_or_path: Union[str, Path] = ":memory:",
        create_if_not_exists: bool = True,
    ) -> None:  # pylint: disable=unused-argument
        super().__init__(db_name_or_path=db_name_or_path, create_if_not_exists=create_if_not_exists)  # type: ignore[misc]
        self._is_connected = (
            True  # super() might set this, but ensure it's True for mock
        )
        # self.db_path is set by super()
        self._object_types: list[ObjectTypeDefinition] = []
        self._object_instances: dict[str, list[ObjectInstance]] = {}
        self._setup_mock_data()

    def _setup_mock_data(self) -> None:
        props_doc = [
            PropertyDefinition(
                name="title", data_type=PropertyDataType.TEXT, is_nullable=False,
            ),
            PropertyDefinition(
                name="pages", data_type=PropertyDataType.INTEGER, is_nullable=True,
            ),
        ]
        doc_type = ObjectTypeDefinition(
            name="Document", properties=props_doc, description="A document type",
        )
        self._object_types.append(doc_type)

        props_person = [
            PropertyDefinition(
                name="name", data_type=PropertyDataType.TEXT, is_nullable=False,
            ),
            PropertyDefinition(
                name="age", data_type=PropertyDataType.INTEGER, is_nullable=True,
            ),
        ]
        person_type = ObjectTypeDefinition(
            name="Person", properties=props_person, description="A person type",
        )
        self._object_types.append(person_type)

        self._object_instances["Document"] = [
            ObjectInstance(
                id=uuid.uuid4(),
                object_type_name="Document",
                properties={"title": "The Great Gatsby", "pages": 180},
                weight=Decimal("1.0"),
            ),
            ObjectInstance(
                id=uuid.uuid4(),
                object_type_name="Document",
                properties={"title": "Moby Dick", "pages": 600},
                weight=Decimal("1.0"),
            ),
        ]
        self._object_instances["Person"] = [
            ObjectInstance(
                id=uuid.uuid4(),
                object_type_name="Person",
                properties={"name": "Alice", "age": 30},
                weight=Decimal("1.0"),
            ),
            ObjectInstance(
                id=uuid.uuid4(),
                object_type_name="Person",
                properties={"name": "Bob", "age": 25},
                weight=Decimal("1.0"),
            ),
        ]

    def list_object_types(self) -> list[ObjectTypeDefinition]:
        QThread.msleep(100)  # Simulate delay
        return self._object_types

    def find_objects(
        self,
        type_name: str,
        filter_criteria: Optional[
            dict[str, Any]
        ] = None,  # pylint: disable=unused-argument
        limit: Optional[int] = None,
    ) -> list[ObjectInstance]:  # pylint: disable=unused-argument
        QThread.msleep(100)
        return self._object_instances.get(type_name, [])

    def get_object_type_definition(
        self, type_name: str,
    ) -> Optional[ObjectTypeDefinition]:
        return next((ot for ot in self._object_types if ot.name == type_name), None)

    def upsert_object(self, obj: ObjectInstance) -> ObjectInstance:
        QThread.msleep(100)
        if not obj.id or str(obj.id) == "00000000-0000-0000-0000-000000000000":
            obj.id = uuid.uuid4()
        obj.upsert_date = datetime.now(timezone.utc)

        type_instances = self._object_instances.setdefault(obj.object_type_name, [])
        # Remove existing if it's an update
        type_instances[:] = [inst for inst in type_instances if inst.id != obj.id]
        type_instances.append(obj)
        return obj

    def delete_object(self, object_id: str, type_name: str) -> bool:
        QThread.msleep(100)
        obj_id_uuid = uuid.UUID(object_id)
        if type_name in self._object_instances:
            initial_len = len(self._object_instances[type_name])
            self._object_instances[type_name][:] = [
                inst
                for inst in self._object_instances[type_name]
                if inst.id != obj_id_uuid
            ]
            return len(self._object_instances[type_name]) < initial_len
        return False

    # Add missing methods from Grizabella base class that Pylint might consider abstract
    def get_relation(
        self, from_object_id: str, to_object_id: str, relation_type_name: str,
    ) -> list[RelationInstance]:  # Corrected return type to match base
        # The base class Grizabella.get_relation returns list[RelationInstance].
        # For a mock, we can return an empty list.
        return []

    def delete_relation(
        self, relation_type_name: str, relation_id: str, # Corrected signature
    ) -> bool:
        # Base class Grizabella.delete_relation returns bool.
        return False


if __name__ == "__main__":
    app = QApplication(sys.argv)
    mock_client_instance = MockGrizabella()

    main_window_container = QWidget()  # Use a simple QWidget as a container
    layout = QVBoxLayout(main_window_container)
    explorer_view_instance = ObjectExplorerView(
        grizabella_client=mock_client_instance,  # type: ignore
    )
    layout.addWidget(explorer_view_instance)

    main_window_container.setWindowTitle("Object Explorer Test")
    main_window_container.setGeometry(100, 100, 900, 700)
    main_window_container.show()

    sys.exit(app.exec())
