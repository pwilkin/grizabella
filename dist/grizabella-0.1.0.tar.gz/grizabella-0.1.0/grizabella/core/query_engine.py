"""Query Planner and Executor for Grizabella's Complex Query Engine."""

import logging
from datetime import datetime
from typing import TYPE_CHECKING, Any, Literal, Optional
from uuid import UUID

from pydantic import BaseModel, Field  # Actual Pydantic import

from grizabella.core.models import (
    ObjectInstance,
    PropertyDataType,
    PropertyDefinition,
)
from grizabella.core.query_models import (
    ComplexQuery,
    EmbeddingSearchClause,
    GraphTraversalClause,
    QueryResult,
    RelationalFilter,
)


logger = logging.getLogger(__name__)

# Forward declaration for type hinting GrizabellaDBManager
if TYPE_CHECKING:
    from grizabella.core.db_manager import GrizabellaDBManager


# New/Updated Pydantic models for planning
class PlannedStep(BaseModel):
    """Represents a single step in an execution plan for a query component."""

    step_type: Literal["sqlite_filter", "lancedb_search", "kuzu_traversal"]
    details: dict[str, Any]
    input_object_ids_source_step_index: Optional[int] = Field(
        default=None,
        description="Index of the step within this component's plan providing input IDs",
    )


class PlannedComponentExecution(BaseModel):
    """Represents the execution plan for a single QueryComponent."""

    component_index: int
    object_type_name: str  # Target object type for this component
    steps: list[PlannedStep]


class PlannedQuery(BaseModel):
    """Represents the full execution plan for a ComplexQuery."""

    original_query: ComplexQuery
    final_target_object_type_name: str  # Primary object type for final result fetching
    component_plans: list[PlannedComponentExecution]


class QueryPlanner:
    """Analyzes a ComplexQuery and decomposes it into an executable plan (PlannedQuery)."""

    def __init__(self, db_manager: "GrizabellaDBManager") -> None:
        """Initializes the QueryPlanner.

        Args:
            db_manager: An instance of GrizabellaDBManager to access schema information.

        """
        self._db_manager = db_manager
        self._schema_manager = db_manager._schema_manager  # Access via db_manager

    def plan(self, query: ComplexQuery) -> PlannedQuery:
        """Generates an execution plan for the given complex query.

        Args:
            query: The ComplexQuery object.

        Returns:
            A PlannedQuery object.

        Raises:
            ValueError: If the query is invalid or schema validation fails.

        """
        logger.info("Planning complex query: %s", query.description or "Untitled Query")

        if not query.components:
            msg = "ComplexQuery must have at least one component."
            raise ValueError(msg)

        # Determine the final target object type from the first component.
        final_target_object_type = query.components[0].object_type_name
        otd_final_target = self._schema_manager.get_object_type_definition(
            final_target_object_type,
        )
        if not otd_final_target:
            msg = (
                f"Primary target ObjectTypeDefinition '{final_target_object_type}' "
                "from first query component not found in schema."
            )
            raise ValueError(
                msg,
            )

        all_component_plans: list[PlannedComponentExecution] = []

        for idx, component in enumerate(query.components):
            component_steps: list[PlannedStep] = []
            current_input_src_idx_for_component: Optional[int] = None
            component_object_type_name = component.object_type_name

            otd_component = self._schema_manager.get_object_type_definition(
                component_object_type_name,
            )
            if not otd_component:
                msg = (
                    f"QueryComponent {idx}: ObjectTypeDefinition "
                    f"'{component_object_type_name}' not found."
                )
                raise ValueError(
                    msg,
                )

            # 1. Relational Filters (SQLite)
            if component.relational_filters:
                for rel_filter in component.relational_filters:
                    prop_def = (
                        self._schema_manager.get_property_definition_for_object_type(
                            component_object_type_name, rel_filter.property_name,
                        )
                    )
                    if not prop_def:
                        msg = (
                            f"QueryComponent {idx}: Property '{rel_filter.property_name}' "
                            f"not found for ObjectType '{component_object_type_name}'."
                        )
                        raise ValueError(
                            msg,
                        )
                    # Operator/value type compatibility check with prop_def.data_type is handled by _validate_relational_filter
                    self._validate_relational_filter(  # Correctly indented inside the loop
                        rel_filter, prop_def, component_object_type_name, idx,
                    )
                # This PlannedStep is for all relational_filters, so it's after the loop.
                component_steps.append(
                    PlannedStep(
                        step_type="sqlite_filter",
                        details={
                            "object_type_name": component_object_type_name,
                            "filters": component.relational_filters,
                        },
                        input_object_ids_source_step_index=None, # First step in a chain
                    ),
                )
                current_input_src_idx_for_component = len(component_steps) - 1

            # 2. Embedding Searches (LanceDB)
            if component.embedding_searches:
                for emb_search in component.embedding_searches:
                    emb_def = self._schema_manager.get_embedding_definition(
                        emb_search.embedding_definition_name,
                    )
                    if not emb_def:
                        msg = (
                            f"QueryComponent {idx}: EmbeddingDefinition "
                            f"'{emb_search.embedding_definition_name}' not found."
                        )
                        raise ValueError(
                            msg,
                        )
                    if emb_def.object_type_name != component_object_type_name:
                        msg = (
                            f"QueryComponent {idx}: EmbeddingDefinition "
                            f"'{emb_search.embedding_definition_name}' "
                            f"is for ObjectType '{emb_def.object_type_name}', but component"
                            f" targets '{component_object_type_name}'."
                        )
                        raise ValueError(
                            msg,
                        )

                    source_prop_on_otd = self._schema_manager.get_property_definition_for_object_type(
                        emb_def.object_type_name, 
                        emb_def.source_property_name,
                    )
                    if not source_prop_on_otd:
                        msg = (
                            f"QueryComponent {idx}: Source property '{emb_def.source_property_name}' "
                            f"defined in EmbeddingDefinition '{emb_def.name}' "
                            f"not found on ObjectType '{emb_def.object_type_name}'."
                        )
                        raise ValueError(msg)

                    if (
                        emb_def.dimensions is not None
                        and len(emb_search.similar_to_payload) != emb_def.dimensions
                    ):
                        msg = (
                            f"QueryComponent {idx}: EmbeddingDefinition "
                            f"'{emb_search.embedding_definition_name}' expects "
                            f"{emb_def.dimensions} dimensions, but query vector has "
                            f"{len(emb_search.similar_to_payload)}."
                        )
                        raise ValueError(
                            msg,
                        )

                    component_steps.append(
                        PlannedStep(
                            step_type="lancedb_search",
                            details={
                                "embedding_search_clause": emb_search,
                                "object_type_name": component_object_type_name,
                            },
                            # If relational_filters ran, this uses their output. Otherwise, it's a starting step.
                            input_object_ids_source_step_index=current_input_src_idx_for_component,
                        ),
                    )
                    current_input_src_idx_for_component = len(component_steps) - 1

            # 3. Graph Traversals (Kuzu)
            if component.graph_traversals:
                for traversal in component.graph_traversals:
                    rtd = self._schema_manager.get_relation_type_definition(
                        traversal.relation_type_name,
                    )
                    if not rtd:
                        msg = (
                            f"QueryComponent {idx}: RelationTypeDefinition "
                            f"'{traversal.relation_type_name}' not found."
                        )
                        raise ValueError(
                            msg,
                        )

                    if component_object_type_name not in rtd.source_object_type_names:
                        msg = (
                            f"QueryComponent {idx}: Relation '{traversal.relation_type_name}' "
                            f"cannot originate from ObjectType '{component_object_type_name}'. "
                            f"Allowed sources: {rtd.source_object_type_names}."
                        )
                        raise ValueError(
                            msg,
                        )

                    target_otd = self._schema_manager.get_object_type_definition(
                        traversal.target_object_type_name,
                    )
                    if not target_otd:
                        msg = (
                            f"QueryComponent {idx}: Target ObjectTypeDefinition "
                            f"'{traversal.target_object_type_name}' in graph traversal not found."
                        )
                        raise ValueError(msg)

                    if (
                        traversal.target_object_type_name
                        not in rtd.target_object_type_names
                    ):
                        msg = (
                            f"QueryComponent {idx}: Relation '{traversal.relation_type_name}' "
                            f"cannot target ObjectType '{traversal.target_object_type_name}'. "
                            f"Allowed targets: {rtd.target_object_type_names}."
                        )
                        raise ValueError(
                            msg,
                        )

                    if traversal.target_object_properties:
                        for rel_filter in traversal.target_object_properties:
                            prop_def = self._schema_manager.get_property_definition_for_object_type(
                                traversal.target_object_type_name,
                                rel_filter.property_name,
                            )
                            if not prop_def:
                                msg = (
                                    f"QueryComponent {idx}: Property '{rel_filter.property_name}' "
                                    f"for graph traversal not found for target ObjectType "
                                    f"'{traversal.target_object_type_name}'."
                                )
                                raise ValueError(
                                    msg,
                                )
                            self._validate_relational_filter(
                                rel_filter,
                                    prop_def,
                                    traversal.target_object_type_name,
                                    idx,
                                    context=f"graph_traversals.target_object_properties (relation: {traversal.relation_type_name})",
                                )
                    component_steps.append(
                        PlannedStep(
                            step_type="kuzu_traversal",
                            details={
                                "source_object_type_name": component_object_type_name,
                                "graph_traversal_clause": traversal,
                            },
                            input_object_ids_source_step_index=current_input_src_idx_for_component,
                        ),
                    )
                    current_input_src_idx_for_component = len(component_steps) - 1
            
            if not component_steps: # If a component has no filters, searches, or traversals
                # This implies we want all objects of this type for this component.
                # This case might need specific handling in the executor if it's a valid scenario.
                # For now, the planner doesn't create a step, executor will need to handle.
                logger.warning(
                    "QueryComponent %d for ObjectType '%s' has no filters, searches, or traversals. "
                    "This may result in all instances of this type being considered for this component.",
                    idx, component_object_type_name
                )


            all_component_plans.append(
                PlannedComponentExecution(
                    component_index=idx,
                    object_type_name=component_object_type_name,
                    steps=component_steps,
                ),
            )

        return PlannedQuery(
            original_query=query,
            final_target_object_type_name=final_target_object_type,
            component_plans=all_component_plans,
        )

    def _validate_relational_filter(
        self,
        rel_filter: RelationalFilter,
        prop_def: PropertyDefinition,
        object_type_name: str,
        component_idx: int,
        context: str = "relational_filters",
    ) -> None:
        """Validates a RelationalFilter's operator and value against its PropertyDefinition."""
        filter_value = rel_filter.value
        prop_type = prop_def.data_type
        operator = rel_filter.operator

        valid = True
        error_msg = ""

        if operator != "IN":
            if (prop_type == PropertyDataType.TEXT and not isinstance(filter_value, str)) or \
               (prop_type == PropertyDataType.INTEGER and not isinstance(filter_value, int)) or \
               (prop_type == PropertyDataType.FLOAT and not isinstance(filter_value, (int, float))) or \
               (prop_type == PropertyDataType.BOOLEAN and not isinstance(filter_value, bool)) or \
               (prop_type == PropertyDataType.DATETIME and not isinstance(filter_value, datetime)):
                valid = False
            elif prop_type == PropertyDataType.UUID:
                if not isinstance(filter_value, UUID):
                    try:
                        UUID(str(filter_value)) 
                    except ValueError:
                        valid = False
            elif prop_type == PropertyDataType.JSON and operator not in ["==", "!="]:
                pass
            elif prop_type == PropertyDataType.BLOB:
                error_msg = f"Filtering on BLOB property '{prop_def.name}' is not generally supported."
                valid = False

        elif operator == "IN":
            if not isinstance(filter_value, list):
                valid = False
                error_msg = f"Value for 'IN' operator on property '{prop_def.name}' must be a list."
            else:
                for item in filter_value:
                    item_valid = False
                    if (prop_type == PropertyDataType.TEXT and isinstance(item, str)) or \
                       (prop_type == PropertyDataType.INTEGER and isinstance(item, int)) or \
                       (prop_type == PropertyDataType.FLOAT and isinstance(item, (int, float))) or \
                       (prop_type == PropertyDataType.BOOLEAN and isinstance(item, bool)) or \
                       (prop_type == PropertyDataType.DATETIME and isinstance(item, datetime)):
                        item_valid = True
                    elif prop_type == PropertyDataType.UUID:
                        if isinstance(item, UUID):
                            item_valid = True
                        else:
                            try:
                                UUID(str(item))
                                item_valid = True
                            except ValueError:
                                pass
                    if not item_valid:
                        valid = False
                        error_msg = (
                            f"Invalid item type in list for 'IN' operator on property "
                            f"'{prop_def.name}'. Expected {prop_type.value}."
                        )
                        break
        if not valid and not error_msg:
            error_msg = (
                f"Value type {type(filter_value).__name__} incompatible with property "
                f"'{prop_def.name}' (type {prop_type.value})."
            )

        if valid: 
            unsupported_operator = False
            if (prop_type == PropertyDataType.TEXT and operator not in ["==", "!=", "LIKE", "IN", "CONTAINS", "STARTSWITH", "ENDSWITH"]) or \
               (prop_type in [PropertyDataType.INTEGER, PropertyDataType.FLOAT] and operator not in ["==", "!=", ">", "<", ">=", "<=", "IN"]) or \
               (prop_type == PropertyDataType.BOOLEAN and operator not in ["==", "!="]) or \
               (prop_type == PropertyDataType.DATETIME and operator not in ["==", "!=", ">", "<", ">=", "<="]) or \
               (prop_type == PropertyDataType.UUID and operator not in ["==", "!=", "IN"]) or \
               (prop_type == PropertyDataType.JSON and operator not in ["==", "!="]):
                unsupported_operator = True

            if unsupported_operator:
                valid = False
                error_msg = (
                    f"Operator '{operator}' not supported for property "
                    f"'{prop_def.name}' of type {prop_type.value}."
                )

        if not valid:
            base_error = (
                f"QueryComponent {component_idx}, {context} for ObjectType "
                f"'{object_type_name}': "
            )
            raise ValueError(base_error + error_msg)


class QueryExecutor:
    """Executes a PlannedQuery using the GrizabellaDBManager and its adapters."""

    def __init__(self, db_manager: "GrizabellaDBManager") -> None:
        """Initializes the QueryExecutor.

        Args:
            db_manager: An instance of GrizabellaDBManager to execute sub-queries.

        """
        self._db_manager = db_manager

    def execute(self, planned_query: PlannedQuery) -> QueryResult:
        """Executes the planned query steps for each component and aggregates results.

        Args:
            planned_query: The PlannedQuery object.

        Returns:
            A QueryResult object.

        """
        logger.info(
            "Executing planned query for: %s",
            planned_query.original_query.description or "Untitled Query",
        )

        all_component_final_ids: list[list[UUID]] = []
        errors: list[str] = []

        for comp_plan_idx, component_plan in enumerate(planned_query.component_plans):
            logger.info(
                "Executing component %d (ObjectType: %s)",
                component_plan.component_index,
                component_plan.object_type_name,
            )
            intermediate_step_results: dict[int, list[UUID]] = {}
            # Initialize current_ids_for_this_component. If no steps modify it (e.g. pure traversal),
            # it should start with all IDs of the component's object_type_name.
            current_ids_for_this_component: Optional[list[UUID]] = None

            # Pre-populate IDs if the component effectively starts with a traversal
            # or has no steps that would generate an initial ID set.
            if not component_plan.steps: # No steps, means all objects of this type
                logger.debug(
                    "Component %d has no steps. Initializing with all IDs for ObjectType '%s'.",
                    comp_plan_idx, component_plan.object_type_name
                )
                current_ids_for_this_component = self._db_manager.sqlite_adapter.get_all_object_ids_for_type(
                    component_plan.object_type_name
                )
                if current_ids_for_this_component is None: # Should not happen if type exists
                    current_ids_for_this_component = []
                logger.debug("Initialized with %d IDs.", len(current_ids_for_this_component))


            for step_idx, step in enumerate(component_plan.steps):
                input_ids_for_step: Optional[list[UUID]] = None

                if step.input_object_ids_source_step_index is not None:
                    # This step depends on a previous step within this component
                    input_ids_for_step = intermediate_step_results.get(
                        step.input_object_ids_source_step_index,
                    )
                elif current_ids_for_this_component is not None:
                    # This is a starting step, but current_ids_for_this_component was already populated
                    # (e.g. by the "no steps" case above, or if we allow multiple independent starting chains later)
                    input_ids_for_step = current_ids_for_this_component
                else:
                    # This is a starting step (no prior step in this component provided IDs),
                    # and current_ids_for_this_component is also None.
                    # This implies we need all objects of the component's type as input.
                    # This is especially for a Kuzu traversal that's the first logical operation.
                    logger.debug(
                        "Component %d, Step %d (%s) is a starting step. "
                        "Fetching all IDs for ObjectType '%s' as initial input.",
                        comp_plan_idx, step_idx, step.step_type, component_plan.object_type_name
                    )
                    input_ids_for_step = self._db_manager.sqlite_adapter.get_all_object_ids_for_type(
                        component_plan.object_type_name
                    )
                    if input_ids_for_step is None: # Should not happen if type exists
                        input_ids_for_step = []
                    logger.debug("Fetched %d initial IDs.", len(input_ids_for_step))


                if input_ids_for_step is None and step.step_type == "kuzu_traversal":
                     # This specific check for Kuzu might now be redundant if the logic above correctly
                     # populates input_ids_for_step. However, keeping it as a safeguard or for clarity.
                    msg = (
                        f"Kuzu traversal (Comp {comp_plan_idx}, Step {step_idx}) "
                        f"requires input IDs, but none were provided after initial population attempt."
                    )
                    logger.error(msg)
                    errors.append(msg)
                    current_ids_for_this_component = [] 
                    break 
                
                if input_ids_for_step is not None and not input_ids_for_step and step.input_object_ids_source_step_index is not None:
                    # A previous step in this component yielded no results, so this step also yields no results.
                    logger.info(
                        "Component %d, Step %d (%s) received no input IDs from prior step %d, "
                        "short-circuiting component.",
                        comp_plan_idx,
                        step_idx,
                        step.step_type,
                        step.input_object_ids_source_step_index,
                    )
                    current_ids_for_this_component = []
                    break

                try:
                    step_output_ids: list[UUID] = []
                    if step.step_type == "sqlite_filter":
                        details = step.details
                        rel_filters: list[RelationalFilter] = details["filters"]
                        obj_type_name: str = details["object_type_name"]

                        step_output_ids = self._db_manager.sqlite_adapter.find_object_ids_by_properties(
                            object_type_name=obj_type_name,
                            filters=rel_filters,
                            initial_ids=input_ids_for_step, 
                        )
                        logger.debug(
                            "SQLite filter step yielded %d IDs", len(step_output_ids),
                        )

                    elif step.step_type == "lancedb_search":
                        emb_clause: EmbeddingSearchClause = step.details[
                            "embedding_search_clause"
                        ]
                        # Returns list of (UUID, distance) tuples
                        results_with_distance = self._db_manager.lancedb_adapter.find_object_ids_by_similarity(
                            embedding_definition_name=emb_clause.embedding_definition_name,
                            query_vector=emb_clause.similar_to_payload,
                            limit=emb_clause.limit, # Adapter already applies limit to candidates
                            initial_ids=input_ids_for_step,
                        )
                        logger.debug(
                            "LanceDB search step (before threshold) yielded %d ID-distance pairs: %s",
                            len(results_with_distance), results_with_distance
                        )

                        # Apply threshold
                        # Threshold is similarity (0-1, higher is better). Distance is L2 (lower is better).
                        # Convert: similarity = 1 / (1 + distance)
                        # Keep if similarity >= threshold  =>  1 / (1 + distance) >= threshold
                        # => 1 >= threshold * (1 + distance)
                        # => 1 >= threshold + threshold * distance
                        # => 1 - threshold >= threshold * distance
                        # => (1 - threshold) / threshold >= distance  (if threshold > 0)
                        # => distance <= (1 / threshold) - 1 (if threshold > 0)

                        filtered_ids: list[UUID] = []
                        if emb_clause.threshold is not None:
                            if emb_clause.is_l2_distance:
                                # Handle L2 distance: smaller is better
                                # Threshold for L2 should be non-negative.
                                # A threshold of 0 means exact match.
                                if emb_clause.threshold < 0:
                                    logger.warning(
                                        "LanceDB L2 search: Negative threshold %s provided. Interpreting as no effective threshold (include all).",
                                        emb_clause.threshold
                                    )
                                    filtered_ids = [res_id for res_id, _ in results_with_distance]
                                else:
                                    for res_id, distance_val in results_with_distance:
                                        if distance_val <= emb_clause.threshold:
                                            filtered_ids.append(res_id)
                                logger.debug(
                                    "LanceDB L2 search step (L2 threshold %s) yielded %d IDs: %s",
                                    emb_clause.threshold, len(filtered_ids), filtered_ids
                                )
                            else:
                                # Handle Cosine similarity: distance is 1 - similarity, so higher similarity (closer to 1) is better
                                # Original logic for cosine-based thresholding:
                                if emb_clause.threshold <= 0:
                                    logger.warning(
                                        "LanceDB Cosine search: threshold %s is <= 0, including all results up to limit.",
                                        emb_clause.threshold
                                    )
                                    filtered_ids = [res_id for res_id, _ in results_with_distance]
                                elif emb_clause.threshold >= 1: # Max similarity
                                    distance_cutoff = 1e-6 # Effectively zero distance for cosine
                                    for res_id, distance_val in results_with_distance:
                                        if distance_val <= distance_cutoff: # distance = 1 - similarity; so 1-sim <= eps => sim >= 1-eps
                                            filtered_ids.append(res_id)
                                else: # 0 < threshold < 1
                                    for res_id, distance_val in results_with_distance:
                                        actual_cosine_similarity = 1.0 - distance_val
                                        if actual_cosine_similarity >= emb_clause.threshold:
                                            filtered_ids.append(res_id)
                                logger.debug(
                                    "LanceDB Cosine search step (similarity threshold %s) yielded %d IDs: %s",
                                    emb_clause.threshold, len(filtered_ids), filtered_ids
                                )
                        else: # No threshold specified
                            filtered_ids = [res_id for res_id, _ in results_with_distance]
                            logger.debug(
                                "LanceDB search step (no threshold) yielded %d IDs: %s",
                                len(filtered_ids), filtered_ids
                            )
                        
                        step_output_ids = filtered_ids

                        if step.details.get("embedding_search_clause"): # Log specifically for embedding search outputs
                            emb_clause_desc = step.details["embedding_search_clause"].embedding_definition_name
                            logger.info(
                                "Component %d, Step %d (lancedb_search for %s, threshold %s) output IDs: %s",
                                comp_plan_idx,
                                step_idx,
                                emb_clause_desc,
                                emb_clause.threshold, # Log the threshold used
                                step_output_ids
                            )

                    elif step.step_type == "kuzu_traversal":
                        trav_clause: GraphTraversalClause = step.details[
                            "graph_traversal_clause"
                        ]
                        source_obj_type_name: str = step.details[
                            "source_object_type_name"
                        ]
                        logger.debug(
                            "Kuzu traversal (Comp %d, Step %d): input_ids_for_step is %s",
                            comp_plan_idx,
                            step_idx,
                            "None" if input_ids_for_step is None else f"{len(input_ids_for_step)} IDs",
                        )
                        if input_ids_for_step is None: 
                            msg = (
                                f"Kuzu traversal (Comp {comp_plan_idx}, Step {step_idx}) "
                                f"requires input IDs, but none were provided."
                            )
                            logger.error(msg)
                            errors.append(msg)
                            step_output_ids = []
                        elif not input_ids_for_step: # Explicitly check for empty list
                            logger.info(
                                "Kuzu traversal (Comp %d, Step %d) received an empty list of input IDs. Skipping traversal.",
                                comp_plan_idx, step_idx
                            )
                            step_output_ids = []
                        else:
                            step_output_ids = self._db_manager.kuzu_adapter.filter_object_ids_by_relations(
                                source_object_type_name=source_obj_type_name,
                                object_ids=input_ids_for_step,
                                traversals=[trav_clause], 
                            )
                        logger.debug(
                            "Kuzu traversal step yielded %d IDs", len(step_output_ids),
                        )
                    else:
                        msg = f"Unknown query step type '{step.step_type}' at component {comp_plan_idx}, step {step_idx}."
                        logger.error(msg)
                        errors.append(msg)
                        step_output_ids = [] 

                    intermediate_step_results[step_idx] = step_output_ids
                    current_ids_for_this_component = step_output_ids  

                    if not current_ids_for_this_component: 
                        logger.info(
                            "Component %d, Step %d (%s) yielded no results. Aborting component execution.",
                            comp_plan_idx,
                            step_idx,
                            step.step_type,
                        )
                        break 

                except Exception as e:
                    msg = f"Error in component {comp_plan_idx}, step {step_idx} ({step.step_type}): {type(e).__name__}: {e}"
                    logger.error(msg, exc_info=True)
                    errors.append(msg)
                    current_ids_for_this_component = [] 
                    break 

            if current_ids_for_this_component is None and component_plan.steps :
                 # This case implies steps existed, but loop was not entered or current_ids_for_this_component was not set.
                 # This should ideally be caught by earlier logic (e.g. if no steps, it's handled before loop)
                 # Or if steps fail, current_ids_for_this_component becomes [].
                 logger.warning("Component %d had steps but current_ids_for_this_component remained None. Defaulting to empty.", comp_plan_idx)
                 current_ids_for_this_component = []
            elif current_ids_for_this_component is None and not component_plan.steps:
                # This is already handled by the pre-population logic if no steps.
                # If it's still None here, it means get_all_object_ids_for_type returned None (which it shouldn't for valid types)
                logger.warning("Component %d had no steps and current_ids_for_this_component is still None. Defaulting to empty.", comp_plan_idx)
                current_ids_for_this_component = []


            all_component_final_ids.append(current_ids_for_this_component if current_ids_for_this_component is not None else [])
            logger.info(
                "Component %d finished with %d IDs.",
                component_plan.component_index,
                len(current_ids_for_this_component if current_ids_for_this_component is not None else []),
            )

        final_aggregated_ids: Optional[list[UUID]] = None
        if not errors: 
            if all_component_final_ids:
                final_aggregated_ids_set = set(all_component_final_ids[0])
                for i in range(1, len(all_component_final_ids)):
                    final_aggregated_ids_set.intersection_update(
                        all_component_final_ids[i],
                    )
                final_aggregated_ids = list(final_aggregated_ids_set)
                logger.info(
                    "Final aggregated query resulted in %d IDs after intersection.",
                    len(final_aggregated_ids),
                )
            else: 
                final_aggregated_ids = []
        else: 
            final_aggregated_ids = []
            logger.warning("Query execution had errors, final ID list is empty.")

        final_instances: list[ObjectInstance] = []
        if final_aggregated_ids:
            try:
                final_instances = self._db_manager.get_objects_by_ids(
                    object_type_name=planned_query.final_target_object_type_name,
                    object_ids=final_aggregated_ids,
                )
                logger.info("Fetched %d full object instances.", len(final_instances))
            except Exception as e:
                msg = f"Error fetching final object instances: {e}"
                logger.error(msg, exc_info=True)
                errors.append(msg)

        return QueryResult(
            object_instances=final_instances, errors=errors if errors else None,
        )
