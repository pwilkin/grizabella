"""Grizabella MCP Server.

This module provides an MCP (Model Context Protocol) server for Grizabella,
exposing its core functionalities as tools that can be called remotely.
It uses FastMCP to define and serve these tools.
"""

import os
from pathlib import Path
from typing import Any, Optional, Union

from fastmcp import FastMCP

# from mcp import ToolContext # MCPTool is not needed when using @app.tool decorator. ToolContext
# might be injected.
from pydantic import BaseModel

from grizabella.api.client import Grizabella
from grizabella.core.exceptions import GrizabellaException
from grizabella.core.models import (
    ObjectInstance,
    ObjectTypeDefinition,
    RelationInstance,
    RelationTypeDefinition,
)
from grizabella.core.query_models import ComplexQuery, QueryResult

# --- Configuration ---
GRIZABELLA_DB_PATH_ENV_VAR = "GRIZABELLA_DB_PATH"
DEFAULT_GRIZABELLA_DB_PATH = "grizabella_mcp_db"


def get_grizabella_db_path() -> Union[str, Path]:
    return os.getenv(GRIZABELLA_DB_PATH_ENV_VAR, DEFAULT_GRIZABELLA_DB_PATH)


# --- Pydantic Models for Request Bodies (if not directly using core models) ---
# FastMCP might handle Pydantic models directly. If so, these might not be strictly necessary
# but can be useful for defining clear API contracts for the MCP tools.
# For now, we'll assume FastMCP can use the core Pydantic models from grizabella.core

# --- MCP Application ---
app = FastMCP()
# TODO: Investigate how to set title, description, version for FastMCP app instance if needed.
# Common ways include app.title = "...", or passing a settings object.


# --- Helper to get Grizabella client ---
def get_grizabella_client() -> Grizabella:
    """Instantiates and returns a Grizabella API client."""
    db_path = get_grizabella_db_path()
    # Ensure the client is connected within each request or use a managed lifecycle if
    # FastMCP supports it. For simplicity, we'll create and connect/close per call, or rely
    # on Grizabella's context manager.
    return Grizabella(db_name_or_path=db_path, create_if_not_exists=True)


# --- MCP Tool Definitions ---


# Schema Management
@app.tool(
    name="create_object_type",
    description="Creates a new object type (e.g., a table or node type).",
)
async def mcp_create_object_type(object_type_def: ObjectTypeDefinition) -> None:
    # ctx: ToolContext,  # Removed for now, FastMCP might inject or not require it.
    try:
        with get_grizabella_client() as gb:
            gb.create_object_type(object_type_def)
        return  # Or a success message
    except GrizabellaException as e:
        # TODO: Map to appropriate MCP error
        msg = f"MCP: Error creating object type '{object_type_def.name}': {e}"
        raise GrizabellaException(msg) from e
    except Exception as e: # pylint: disable=broad-except
        msg = f"MCP: Unexpected error creating object type '{object_type_def.name}': {e}"
        raise Exception(msg) from e


@app.tool(
    name="get_object_type",
    description="Retrieves the definition of an object type.",
)
async def mcp_get_object_type(type_name: str) -> Optional[ObjectTypeDefinition]:
    # ctx: ToolContext,
    try:
        with get_grizabella_client() as gb:
            return gb.get_object_type_definition(type_name)  # Corrected method name
    except GrizabellaException as e:
        msg = f"MCP: Error getting object type '{type_name}': {e}"
        raise GrizabellaException(msg) from e
    except Exception as e: # pylint: disable=broad-except
        msg = f"MCP: Unexpected error getting object type '{type_name}': {e}"
        raise Exception(msg) from e


@app.tool(
    name="delete_object_type",
    description="Deletes an object type.",
)
async def mcp_delete_object_type(type_name: str) -> None:
    # ctx: ToolContext,
    try:
        with get_grizabella_client() as gb:
            gb.delete_object_type(type_name)
        return
    except GrizabellaException as e:
        msg = f"MCP: Error deleting object type '{type_name}': {e}"
        raise GrizabellaException(msg) from e
    except Exception as e: # pylint: disable=broad-except
        msg = f"MCP: Unexpected error deleting object type '{type_name}': {e}"
        raise Exception(msg) from e


@app.tool(
    name="create_relation_type",
    description="Creates a new relation type.",
)
async def mcp_create_relation_type(relation_type_def: RelationTypeDefinition) -> None:
    # ctx: ToolContext,
    try:
        with get_grizabella_client() as gb:
            gb.create_relation_type(relation_type_def)
        return
    except GrizabellaException as e:
        msg = f"MCP: Error creating relation type '{relation_type_def.name}': {e}"
        raise GrizabellaException(msg) from e
    except Exception as e: # pylint: disable=broad-except
        msg = f"MCP: Unexpected error creating relation type '{relation_type_def.name}': {e}"
        raise Exception(msg) from e


@app.tool(
    name="get_relation_type",
    description="Retrieves the definition of a relation type.",
)
async def mcp_get_relation_type(type_name: str) -> Optional[RelationTypeDefinition]:
    # ctx: ToolContext,
    try:
        with get_grizabella_client() as gb:
            return gb.get_relation_type(type_name)
    except GrizabellaException as e:
        msg = f"MCP: Error getting relation type '{type_name}': {e}"
        raise GrizabellaException(msg) from e
    except Exception as e: # pylint: disable=broad-except
        msg = f"MCP: Unexpected error getting relation type '{type_name}': {e}"
        raise Exception(msg) from e


@app.tool(
    name="delete_relation_type",
    description="Deletes a relation type.",
)
async def mcp_delete_relation_type(type_name: str) -> None:
    # ctx: ToolContext,
    try:
        with get_grizabella_client() as gb:
            gb.delete_relation_type(type_name)
        return
    except GrizabellaException as e:
        msg = f"MCP: Error deleting relation type '{type_name}': {e}"
        raise GrizabellaException(msg) from e
    except Exception as e: # pylint: disable=broad-except
        msg = f"MCP: Unexpected error deleting relation type '{type_name}': {e}"
        raise Exception(msg) from e


# Object Instance Management
@app.tool(
    name="upsert_object",
    description="Creates or updates an object.",
)
async def mcp_upsert_object(obj: ObjectInstance) -> ObjectInstance:
    # ctx: ToolContext,
    try:
        with get_grizabella_client() as gb:
            return gb.upsert_object(obj)
    except GrizabellaException as e:
        msg = f"MCP: Error upserting object '{obj.id}' of type '{obj.object_type_name}': {e}"
        raise GrizabellaException(msg) from e
    except Exception as e: # pylint: disable=broad-except
        msg = f"MCP: Unexpected error upserting object '{obj.id}' of type '{obj.object_type_name}': {e}"
        raise Exception(msg) from e


@app.tool(
    name="get_object_by_id",
    description="Retrieves an object by its ID and type.",
)
async def mcp_get_object_by_id(
    object_id: str, type_name: str,
) -> Optional[ObjectInstance]:
    # ctx: ToolContext,
    try:
        with get_grizabella_client() as gb:
            return gb.get_object_by_id(object_id, type_name)
    except GrizabellaException as e:
        msg = f"MCP: Error getting object '{object_id}' of type '{type_name}': {e}"
        raise GrizabellaException(msg) from e
    except Exception as e: # pylint: disable=broad-except
        msg = f"MCP: Unexpected error getting object '{object_id}' of type '{type_name}': {e}"
        raise Exception(msg) from e


@app.tool(
    name="delete_object",
    description="Deletes an object by its ID and type.",
)
async def mcp_delete_object(object_id: str, type_name: str) -> bool:
    # ctx: ToolContext,
    try:
        with get_grizabella_client() as gb:
            return gb.delete_object(object_id, type_name)
    except GrizabellaException as e:
        msg = f"MCP: Error deleting object '{object_id}' of type '{type_name}': {e}"
        raise GrizabellaException(msg) from e
    except Exception as e: # pylint: disable=broad-except
        msg = f"MCP: Unexpected error deleting object '{object_id}' of type '{type_name}': {e}"
        raise Exception(msg) from e


class FindObjectsArgs(BaseModel):
    type_name: str
    filter_criteria: Optional[dict[str, Any]] = None
    limit: Optional[int] = None


@app.tool(
    name="find_objects",
    description="Finds objects of a given type, optionally matching filter criteria.",
)
async def mcp_find_objects(args: FindObjectsArgs) -> list[ObjectInstance]:
    # ctx: ToolContext,
    try:
        with get_grizabella_client() as gb:
            return gb.find_objects(
                type_name=args.type_name,
                filter_criteria=args.filter_criteria,
                limit=args.limit,
            )
    except GrizabellaException as e:
        msg = f"MCP: Error finding objects of type '{args.type_name}': {e}"
        raise GrizabellaException(msg) from e
    except Exception as e: # pylint: disable=broad-except
        msg = f"MCP: Unexpected error finding objects of type '{args.type_name}': {e}"
        raise Exception(msg) from e


# Relation Instance Management
@app.tool(
    name="add_relation",
    description="Adds a new relation between two objects.",
)
async def mcp_add_relation(relation: RelationInstance) -> RelationInstance:
    # ctx: ToolContext,
    try:
        with get_grizabella_client() as gb:
            return gb.add_relation(relation)
    except GrizabellaException as e:
        msg = f"MCP: Error adding relation '{relation.id}' of type '{relation.relation_type_name}': {e}"
        raise GrizabellaException(msg) from e
    except Exception as e: # pylint: disable=broad-except
        msg = f"MCP: Unexpected error adding relation '{relation.id}' of type '{relation.relation_type_name}': {e}"
        raise Exception(msg) from e


@app.tool(
    name="get_relation",
    description="Retrieves a specific relation between two objects.",
)
async def mcp_get_relation(
    from_object_id: str, to_object_id: str, relation_type_name: str,
) -> list[RelationInstance]: # Changed return type
    # ctx: ToolContext,
    try:
        with get_grizabella_client() as gb:
            return gb.get_relation(from_object_id, to_object_id, relation_type_name)
    except GrizabellaException as e:
        msg = f"MCP: Error getting relation of type '{relation_type_name}' from '{from_object_id}' to '{to_object_id}': {e}"
        raise GrizabellaException(msg) from e
    except Exception as e: # pylint: disable=broad-except
        msg = f"MCP: Unexpected error getting relation of type '{relation_type_name}' from '{from_object_id}' to '{to_object_id}': {e}"
        raise Exception(msg) from e


@app.tool(
    name="delete_relation",
    description="Deletes a specific relation between two objects.",
)
async def mcp_delete_relation(
    relation_type_name: str, relation_id: str, # Changed parameters
) -> bool:
    # ctx: ToolContext,
    try:
        with get_grizabella_client() as gb:
            # Grizabella client's delete_relation now takes relation_type_name and relation_id
            return gb.delete_relation(relation_type_name, relation_id)
    except GrizabellaException as e:
        msg = f"MCP: Error deleting relation '{relation_id}' of type '{relation_type_name}': {e}"
        raise GrizabellaException(msg) from e
    except Exception as e: # pylint: disable=broad-except
        msg = f"MCP: Unexpected error deleting relation '{relation_id}' of type '{relation_type_name}': {e}"
        raise Exception(msg) from e


class GetRelationsArgs(BaseModel):
    object_id: str
    type_name: str
    relation_type_name: Optional[str] = None


@app.tool(
    name="get_outgoing_relations",
    description="Retrieves all outgoing relations from a given object.",
)
async def mcp_get_outgoing_relations(args: GetRelationsArgs) -> list[RelationInstance]:
    # ctx: ToolContext,
    try:
        with get_grizabella_client() as gb:
            return gb.get_outgoing_relations(
                object_id=args.object_id,
                type_name=args.type_name,
                relation_type_name=args.relation_type_name,
            )
    except GrizabellaException as e:
        msg = f"MCP: Error getting outgoing relations for object '{args.object_id}': {e}"
        raise GrizabellaException(msg) from e
    except Exception as e: # pylint: disable=broad-except
        msg = f"MCP: Unexpected error getting outgoing relations for object '{args.object_id}': {e}"
        raise Exception(msg) from e


@app.tool(
    name="get_incoming_relations",
    description="Retrieves all incoming relations to a given object.",
)
async def mcp_get_incoming_relations(args: GetRelationsArgs) -> list[RelationInstance]:
    # ctx: ToolContext,
    try:
        with get_grizabella_client() as gb:
            return gb.get_incoming_relations(
                object_id=args.object_id,
                type_name=args.type_name,
                relation_type_name=args.relation_type_name,
            )
    except GrizabellaException as e:
        msg = f"MCP: Error getting incoming relations for object '{args.object_id}': {e}"
        raise GrizabellaException(msg) from e
    except Exception as e: # pylint: disable=broad-except
        msg = f"MCP: Unexpected error getting incoming relations for object '{args.object_id}': {e}"
        raise Exception(msg) from e


# Querying
class SearchSimilarObjectsArgs(BaseModel):
    object_id: str
    type_name: str
    n_results: int = 5
    search_properties: Optional[list[str]] = None


@app.tool(
    name="search_similar_objects",
    description="Searches for objects similar to a given object, typically using embeddings.",
)
async def mcp_search_similar_objects(
    args: SearchSimilarObjectsArgs,
) -> list[tuple[ObjectInstance, float]]:
    # ctx: ToolContext,
    try:
        with get_grizabella_client() as gb:
            # The Grizabella client's search_similar_objects currently raises NotImplementedError.
            # We must call it to respect the interface, but handle the expected error.
            # If it were implemented, results would be List[Tuple[ObjectInstance, float]].
            # For now, to satisfy Pylint and type checkers if the method were to return,
            # we can assign and then immediately handle the expected NotImplementedError.
            # However, a cleaner approach is to directly call and handle.

            # Attempt the call and handle NotImplementedError specifically.
            # Other GrizabellaExceptions or general Exceptions will be caught below.
            try:
                # This line will raise NotImplementedError based on current client.py
                results: list[tuple[ObjectInstance, float]] = gb.search_similar_objects(
                    object_id=args.object_id,
                    type_name=args.type_name,
                    n_results=args.n_results,
                    search_properties=args.search_properties,
                )
                return results # This line will not be reached if NotImplementedError is raised
            except NotImplementedError as nie:
                # Specific handling for the known unimplemented feature.
                # Raising a general Exception here for the MCP layer is acceptable to signal this state.
                msg = f"MCP: search_similar_objects feature is not yet implemented in the Grizabella client: {nie}"
                raise Exception(msg) from nie

    except GrizabellaException as e:
        # Handle other Grizabella-specific errors, re-raise as GrizabellaException
        msg = f"MCP: Error searching similar objects for '{args.object_id}': {e}"
        raise GrizabellaException(msg) from e
    except Exception as e: # pylint: disable=broad-except
        # Handle any other unexpected errors, re-raise as general Exception
        msg = f"MCP: Unexpected error searching similar objects for '{args.object_id}': {e}"
        raise Exception(msg) from e


@app.tool(
    name="execute_complex_query",
    description="Executes a complex query spanning multiple database layers.",
)
async def mcp_execute_complex_query(query: ComplexQuery) -> QueryResult:
    # ctx: ToolContext,
    try:
        with get_grizabella_client() as gb:
            return gb.execute_complex_query(query)
    except GrizabellaException as e:
        msg = f"MCP: Error executing complex query '{query.description}': {e}"
        raise GrizabellaException(msg) from e
    except Exception as e: # pylint: disable=broad-except
        msg = f"MCP: Unexpected error executing complex query '{query.description}': {e}"
        raise Exception(msg) from e


# To run this server (example using uvicorn, if FastMCP is FastAPI/Starlette based):
# Ensure FastMCP documentation is checked for the correct way to run the server.
# If FastMCP provides its own CLI runner, use that.
# Example: uvicorn grizabella.mcp.server:app --reload
#
# The main FastMCP object `app` would typically be run by a command like:
# `python -m fastmcp grizabella.mcp.server:app`
# or similar, depending on FastMCP's conventions.

def main():
    """Runs the FastMCP application."""
    app.run()
if __name__ == "__main__":
    # This allows the server to be run directly, defaulting to Stdio transport.
    app.run()
