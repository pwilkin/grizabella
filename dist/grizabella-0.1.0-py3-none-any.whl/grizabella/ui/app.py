"""Grizabella UI Application.

This module contains the main entry point for launching the Grizabella
PySide6 user interface.
"""
import sys

from PySide6.QtWidgets import QApplication

from .main_window import MainWindow


def main() -> None:
    """Main function to initialize and run the Grizabella UI application."""
    app = QApplication(sys.argv)
    main_win = MainWindow()
    main_win.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
