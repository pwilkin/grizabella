"""View for managing ObjectTypeDefinitions."""
from typing import TYPE_CHECKING, Optional

from PySide6.QtCore import Qt, QThread, Signal, Slot
from PySide6.QtWidgets import (
    QAbstractItemView,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,  # Added QTableWidgetItem
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from grizabella.core.exceptions import SchemaError

# Added PropertyDataType for mock
from grizabella.core.models import ObjectTypeDefinition, PropertyDataType, PropertyDefinition
from grizabella.ui.dialogs.object_type_dialog import ObjectTypeDialog

if TYPE_CHECKING:
    from grizabella.api.client import Grizabella


class ObjectTypeListWorker(QThread):
    """Worker thread for fetching object types."""

    success = Signal(list) # List[ObjectTypeDefinition]
    failed = Signal(str)

    def __init__(self, client: "Grizabella", parent=None) -> None:
        super().__init__(parent)
        self.client = client

    def run(self) -> None:
        try:
            if (hasattr(self.client, "list_object_types") and
                    callable(self.client.list_object_types)):
                otds = self.client.list_object_types()
                self.success.emit(otds if otds else [])
            else:
                self.failed.emit("Client does not support 'list_object_types'.")
        except Exception as e:
            self.failed.emit(f"Failed to list object types: {e!s}")

class ObjectTypeDeleteWorker(QThread):
    """Worker thread for deleting an object type."""

    success = Signal(str) # Name of deleted OTD
    failed = Signal(str)

    def __init__(self, client: "Grizabella", otd_name: str, parent=None) -> None:
        super().__init__(parent)
        self.client = client
        self.otd_name = otd_name

    def run(self) -> None:
        try:
            if (hasattr(self.client, "delete_object_type") and
                    callable(self.client.delete_object_type)):
                self.client.delete_object_type(self.otd_name)
                self.success.emit(self.otd_name)
            else:
                self.failed.emit("Client does not support 'delete_object_type'.")
        except SchemaError as e:
            self.failed.emit(f"Schema Error: {e!s}")
        except Exception as e:
            self.failed.emit(
                f"Failed to delete object type '{self.otd_name}': {e!s}",
            )


class ObjectTypeView(QWidget):
    """QWidget for displaying and managing ObjectTypeDefinitions."""

    def __init__(self, grizabella_client: Optional["Grizabella"] = None,
                 parent=None) -> None:
        super().__init__(parent)
        self.grizabella_client = grizabella_client
        self.current_otds: list[ObjectTypeDefinition] = []
        self.list_worker_thread: Optional[ObjectTypeListWorker] = None
        self.delete_worker_thread: Optional[ObjectTypeDeleteWorker] = None

        self._init_ui()
        self.set_client(self.grizabella_client)

    def _init_ui(self) -> None:
        main_layout = QHBoxLayout(self)

        left_layout = QVBoxLayout()

        self.ot_list_widget = QListWidget()
        self.ot_list_widget.setSelectionMode(
            QAbstractItemView.SelectionMode.SingleSelection,
        )
        self.ot_list_widget.currentItemChanged.connect(self._on_ot_selected)
        left_layout.addWidget(QLabel("Object Types:"))
        left_layout.addWidget(self.ot_list_widget)

        action_buttons_layout = QHBoxLayout()
        self.new_ot_button = QPushButton("New Object Type")
        self.edit_ot_button = QPushButton("Edit Selected")
        self.delete_ot_button = QPushButton("Delete Selected")
        self.refresh_button = QPushButton("Refresh List")

        self.new_ot_button.clicked.connect(self._create_new_otd)
        self.edit_ot_button.clicked.connect(self._edit_selected_otd)
        self.delete_ot_button.clicked.connect(self._delete_selected_otd)
        self.refresh_button.clicked.connect(self.refresh_object_types)

        action_buttons_layout.addWidget(self.new_ot_button)
        action_buttons_layout.addWidget(self.edit_ot_button)
        action_buttons_layout.addWidget(self.delete_ot_button)
        action_buttons_layout.addStretch()
        action_buttons_layout.addWidget(self.refresh_button)
        left_layout.addLayout(action_buttons_layout)

        details_groupbox = QGroupBox("Object Type Details")
        details_layout = QVBoxLayout()

        form_layout = QFormLayout()
        self.name_display = QLineEdit()
        self.name_display.setReadOnly(True)
        self.description_display = QTextEdit()
        self.description_display.setReadOnly(True)
        self.description_display.setFixedHeight(80)

        form_layout.addRow("Name:", self.name_display)
        form_layout.addRow("Description:", self.description_display)
        details_layout.addLayout(form_layout)

        details_layout.addWidget(QLabel("Properties:"))
        self.properties_table = QTableWidget()
        self.properties_table.setColumnCount(7)
        self.properties_table.setHorizontalHeaderLabels([
            "Name", "Data Type", "PK", "Nullable", "Indexed", "Unique",
            "Description",
        ])
        header = self.properties_table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        for i in range(2, 6):
            header.setSectionResizeMode(i, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(6, QHeaderView.ResizeMode.Stretch)
        self.properties_table.setEditTriggers(
            QAbstractItemView.EditTrigger.NoEditTriggers,
        )
        details_layout.addWidget(self.properties_table)

        details_groupbox.setLayout(details_layout)

        main_layout.addLayout(left_layout, 1)
        main_layout.addWidget(details_groupbox, 2)

        self._clear_details()
        self._update_action_buttons_state()

    def set_client(self, client: Optional["Grizabella"]) -> None:
        self.grizabella_client = client
        if self.grizabella_client:
            self.refresh_object_types()
            self.new_ot_button.setEnabled(True)
            self.refresh_button.setEnabled(True)
        else:
            self.ot_list_widget.clear()
            self.current_otds = []
            self._clear_details()
            self.new_ot_button.setEnabled(False)
            self.refresh_button.setEnabled(False)
        self._update_action_buttons_state()

    def refresh_object_types(self) -> None:
        if not self.grizabella_client:
            QMessageBox.warning(self, "Client Not Available",
                                "Grizabella client is not connected.")
            return

        if self.list_worker_thread and self.list_worker_thread.isRunning():
            return

        self.ot_list_widget.setEnabled(False)
        self.refresh_button.setEnabled(False)
        self.list_worker_thread = ObjectTypeListWorker(self.grizabella_client)
        self.list_worker_thread.success.connect(self._populate_ot_list)
        self.list_worker_thread.failed.connect(self._handle_list_failure)
        self.list_worker_thread.finished.connect(self._on_list_worker_finished)
        self.list_worker_thread.start()

    @Slot(list)
    def _populate_ot_list(self, otds: list[ObjectTypeDefinition]) -> None:
        self.current_otds = sorted(otds, key=lambda otd: otd.name.lower())
        self.ot_list_widget.clear()
        if not self.current_otds:
            self.ot_list_widget.addItem(
                QListWidgetItem("No object types defined."),
            )
            self.ot_list_widget.setEnabled(False)
            self._clear_details()
        else:
            for otd in self.current_otds:
                item = QListWidgetItem(otd.name)
                item.setData(Qt.ItemDataRole.UserRole, otd)
                self.ot_list_widget.addItem(item)
            self.ot_list_widget.setEnabled(True)
            if self.ot_list_widget.count() > 0:
                self.ot_list_widget.setCurrentRow(0)

        self._update_action_buttons_state()

    @Slot(str)
    def _handle_list_failure(self, error_message: str) -> None:
        QMessageBox.critical(self, "Error Listing Object Types", error_message)
        self.ot_list_widget.clear()
        self.ot_list_widget.addItem(
            QListWidgetItem("Error loading object types."),
        )
        self.current_otds = []
        self._clear_details()
        self._update_action_buttons_state()

    @Slot()
    def _on_list_worker_finished(self) -> None:
        if not self.current_otds:
            self.ot_list_widget.setEnabled(False)
        else:
            self.ot_list_widget.setEnabled(True)
        self.refresh_button.setEnabled(True)
        if self.list_worker_thread:
            self.list_worker_thread.deleteLater()
            self.list_worker_thread = None

    def _on_ot_selected(self, current_item: Optional[QListWidgetItem],
                        _previous_item: Optional[QListWidgetItem]) -> None: # Marked unused
        if current_item:
            otd: Optional[ObjectTypeDefinition] = current_item.data(
                Qt.ItemDataRole.UserRole,
            )
            if otd and isinstance(otd, ObjectTypeDefinition):
                self._display_ot_details(otd)
            else:
                self._clear_details()
        else:
            self._clear_details()
        self._update_action_buttons_state()

    def _display_ot_details(self, otd: ObjectTypeDefinition) -> None:
        self.name_display.setText(otd.name)
        self.description_display.setPlainText(otd.description or "")

        self.properties_table.setRowCount(0)
        for prop_def in otd.properties:
            row_position = self.properties_table.rowCount()
            self.properties_table.insertRow(row_position)

            self.properties_table.setItem(row_position, 0,
                                          QTableWidgetItem(prop_def.name))
            self.properties_table.setItem(row_position, 1,
                                          QTableWidgetItem(prop_def.data_type.value))

            pk_item = QTableWidgetItem("Yes" if prop_def.is_primary_key else "No")
            pk_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.properties_table.setItem(row_position, 2, pk_item)

            nullable_item = QTableWidgetItem("Yes" if prop_def.is_nullable else "No")
            nullable_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.properties_table.setItem(row_position, 3, nullable_item)

            indexed_item = QTableWidgetItem("Yes" if prop_def.is_indexed else "No")
            indexed_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.properties_table.setItem(row_position, 4, indexed_item)

            unique_item = QTableWidgetItem("Yes" if prop_def.is_unique else "No")
            unique_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.properties_table.setItem(row_position, 5, unique_item)

            self.properties_table.setItem(
                row_position, 6, QTableWidgetItem(prop_def.description or ""),
            )
        self.properties_table.resizeColumnsToContents()

    def _clear_details(self) -> None:
        self.name_display.clear()
        self.description_display.clear()
        self.properties_table.setRowCount(0)

    def _update_action_buttons_state(self) -> None:
        has_client = self.grizabella_client is not None
        selected_otd_item = self.ot_list_widget.currentItem()
        is_valid_otd_selected = False
        if selected_otd_item:
            data = selected_otd_item.data(Qt.ItemDataRole.UserRole)
            is_valid_otd_selected = isinstance(data, ObjectTypeDefinition)

        self.new_ot_button.setEnabled(has_client)
        self.edit_ot_button.setEnabled(has_client and is_valid_otd_selected)
        self.delete_ot_button.setEnabled(has_client and is_valid_otd_selected)
        self.refresh_button.setEnabled(has_client)

    def _create_new_otd(self) -> None:
        if not self.grizabella_client:
            QMessageBox.critical(self, "Error", "Grizabella client not available.")
            return

        dialog = ObjectTypeDialog(self.grizabella_client, parent=self)
        dialog.object_type_changed.connect(self.refresh_object_types)
        dialog.exec()

    def _edit_selected_otd(self) -> None:
        if not self.grizabella_client:
            QMessageBox.critical(self, "Error", "Grizabella client not available.")
            return

        selected_item = self.ot_list_widget.currentItem()
        if not selected_item:
            QMessageBox.warning(self, "No Selection",
                                "Please select an Object Type to edit.")
            return

        otd_to_edit: Optional[ObjectTypeDefinition] = selected_item.data(
            Qt.ItemDataRole.UserRole,
        )
        if not isinstance(otd_to_edit, ObjectTypeDefinition):
            QMessageBox.warning(self, "Invalid Selection",
                                "The selected item is not a valid Object Type.")
            return

        dialog = ObjectTypeDialog(self.grizabella_client,
                                  existing_otd=otd_to_edit, parent=self)
        dialog.object_type_changed.connect(self.refresh_object_types)
        if dialog.exec():
            QMessageBox.information(
                self, "Edit",
                f"Edit dialog for '{otd_to_edit.name}' was opened. "
                "Full edit functionality pending.",
            )
        else:
            QMessageBox.information(
                self, "Edit",
                f"Edit dialog for '{otd_to_edit.name}' was cancelled.",
            )

    def _delete_selected_otd(self) -> None:
        if not self.grizabella_client:
            QMessageBox.critical(self, "Error", "Grizabella client not available.")
            return

        selected_item = self.ot_list_widget.currentItem()
        if not selected_item:
            QMessageBox.warning(self, "No Selection",
                                "Please select an Object Type to delete.")
            return

        otd_to_delete: Optional[ObjectTypeDefinition] = selected_item.data(
            Qt.ItemDataRole.UserRole,
        )
        if not isinstance(otd_to_delete, ObjectTypeDefinition):
            QMessageBox.warning(self, "Invalid Selection",
                                "The selected item is not a valid Object Type.")
            return

        msg_box = QMessageBox(self)
        msg_box.setIcon(QMessageBox.Icon.Question)
        msg_box.setWindowTitle("Confirm Delete")
        msg_box.setText(
            f"Are you sure you want to delete Object Type '{otd_to_delete.name}'?",
        )
        msg_box.setInformativeText("This action cannot be undone.")
        msg_box.setStandardButtons(
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        msg_box.setDefaultButton(QMessageBox.StandardButton.No)
        reply = msg_box.exec()


        if reply == QMessageBox.StandardButton.Yes:
            if self.delete_worker_thread and self.delete_worker_thread.isRunning():
                QMessageBox.information(
                    self, "In Progress",
                    "Another delete operation is already in progress.",
                )
                return

            self.delete_worker_thread = ObjectTypeDeleteWorker(
                self.grizabella_client, otd_to_delete.name,
            )
            self.delete_worker_thread.success.connect(self._handle_delete_success)
            self.delete_worker_thread.failed.connect(self._handle_delete_failure)
            self.delete_worker_thread.finished.connect(
                self._on_delete_worker_finished,
            )
            self.delete_worker_thread.start()
            self.delete_ot_button.setEnabled(False)

    @Slot(str)
    def _handle_delete_success(self, otd_name: str) -> None:
        QMessageBox.information(self, "Success",
                                f"Object Type '{otd_name}' deleted successfully.")
        self.refresh_object_types()

    @Slot(str)
    def _handle_delete_failure(self, error_message: str) -> None:
        QMessageBox.critical(self, "Delete Failed", error_message)

    @Slot()
    def _on_delete_worker_finished(self) -> None:
        self._update_action_buttons_state()
        if self.delete_worker_thread:
            self.delete_worker_thread.deleteLater()
            self.delete_worker_thread = None

    def closeEvent(self, _event) -> None: # Mark event as unused
        if self.list_worker_thread and self.list_worker_thread.isRunning():
            self.list_worker_thread.quit()
            self.list_worker_thread.wait(100)
        if self.delete_worker_thread and self.delete_worker_thread.isRunning():
            self.delete_worker_thread.quit()
            self.delete_worker_thread.wait(100)
        super().closeEvent(_event)


if __name__ == "__main__":
    import sys

    from PySide6.QtWidgets import QApplication

    # Import the actual client here for the mock to inherit from
    from grizabella.api.client import Grizabella

    # Define MockGrizabellaClientForTest directly in the __main__ block
    class MockGrizabellaClientForTest(Grizabella): # Inherit from Grizabella
        """Mock Grizabella client for standalone testing."""

        _otds_data: dict[str, ObjectTypeDefinition] = {}
        _seq: int = 0

        def __init__(self, db_name_or_path: str = "mock", create_if_not_exists: bool = False) -> None: # Match base
            # Minimal init for mock.
            # super().__init__(db_name_or_path, create_if_not_exists) # Avoid actual DB connection
            self._is_connected = True # Pretend to be connected

            prop1 = PropertyDefinition(
                name="id", data_type=PropertyDataType.UUID, is_primary_key=True,
            )
            prop2 = PropertyDefinition(
                name="title", data_type=PropertyDataType.TEXT, is_nullable=False,
            )
            prop3 = PropertyDefinition(
                name="pages", data_type=PropertyDataType.INTEGER,
            )
            otd1 = ObjectTypeDefinition(
                name="Book", description="A literary work.",
                properties=[prop1, prop2, prop3],
            )
            self._otds_data[otd1.name] = otd1

            prop_a = PropertyDefinition(
                name="name", data_type=PropertyDataType.TEXT, is_primary_key=True,
            )
            prop_b = PropertyDefinition(
                name="age", data_type=PropertyDataType.INTEGER,
            )
            otd2 = ObjectTypeDefinition(
                name="Author", description="Writer of books.",
                properties=[prop_a, prop_b],
            )
            self._otds_data[otd2.name] = otd2

        def list_object_types(self) -> list[ObjectTypeDefinition]:
            return list(self._otds_data.values())

        def create_object_type(self, object_type_def: ObjectTypeDefinition) -> None: # Match base
            if object_type_def.name in self._otds_data:
                msg = f"Object type '{object_type_def.name}' already exists."
                raise SchemaError(
                    msg,
                )
            self._otds_data[object_type_def.name] = object_type_def
            # Original Grizabella.create_object_type returns None

        def delete_object_type(self, type_name: str) -> None: # Match base
            if type_name not in self._otds_data:
                msg = f"Object type '{type_name}' not found."
                raise SchemaError(msg)
            del self._otds_data[type_name]

        # Add other necessary overrides if ObjectTypeView calls them,
        # ensuring their signatures match Grizabella client methods.
        # For example, if connect/close are called:
        def connect(self) -> None:
            self._is_connected = True

        def close(self) -> None:
            self._is_connected = False

    app = QApplication(sys.argv)
    mock_client_instance = MockGrizabellaClientForTest()
    main_view_instance = ObjectTypeView(grizabella_client=mock_client_instance)
    main_view_instance.setWindowTitle("Grizabella Object Type Management")
    main_view_instance.resize(900, 600)
    main_view_instance.show()
    sys.exit(app.exec())

