"""View for exploring and managing Relation Instances in Grizabella."""
import uuid
from typing import Any, Optional

from PySide6.QtCore import QTimer, Slot
from PySide6.QtWidgets import QAbstractItemView, QComboBox, QHBoxLayout, QLabel, QLineEdit, QMessageBox, QPushButton, QTableView, QVBoxLayout, QWidget

from grizabella.api.client import Grizabella  # Corrected import
from grizabella.core.models import RelationInstance, RelationTypeDefinition
from grizabella.ui.dialogs.relation_instance_dialog import RelationInstanceDialog
from grizabella.ui.models.relation_instance_table_model import RelationInstanceTableModel
from grizabella.ui.threads import ApiClientThread


class RelationExplorerView(QWidget):
    """View for exploring and managing RelationInstances."""

    def __init__(self, grizabella_client: Optional[Grizabella], # Corrected type hint
                 parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.grizabella_client = grizabella_client
        self.relation_types: list[RelationTypeDefinition] = []
        self.current_selected_relation_type: Optional[RelationTypeDefinition] = None
        self._api_thread: Optional[ApiClientThread] = None

        self.setWindowTitle("Relation Explorer")
        self._main_layout = QVBoxLayout(self)

        # Top Controls: Relation Type Selection and Filters
        controls_layout = QHBoxLayout()

        # Relation Type ComboBox
        self.relation_type_combo = QComboBox()
        self.relation_type_combo.setPlaceholderText("Select Relation Type...")
        self.relation_type_combo.currentIndexChanged.connect(self._on_relation_type_selected)
        controls_layout.addWidget(QLabel("Relation Type:"))
        controls_layout.addWidget(self.relation_type_combo, 1)

        # Filter LineEdits
        self.source_id_filter_edit = QLineEdit()
        self.source_id_filter_edit.setPlaceholderText("Filter by Source Object ID (UUID)...")
        self.source_id_filter_edit.textChanged.connect(self._schedule_filter_relations)
        controls_layout.addWidget(QLabel("Source ID:"))
        controls_layout.addWidget(self.source_id_filter_edit, 1)

        self.target_id_filter_edit = QLineEdit()
        self.target_id_filter_edit.setPlaceholderText("Filter by Target Object ID (UUID)...")
        self.target_id_filter_edit.textChanged.connect(self._schedule_filter_relations)
        controls_layout.addWidget(QLabel("Target ID:"))
        controls_layout.addWidget(self.target_id_filter_edit, 1)

        self._filter_timer = QTimer(self)
        self._filter_timer.setSingleShot(True)
        self._filter_timer.setInterval(500) # 500ms delay
        self._filter_timer.timeout.connect(self._filter_relations)


        self._main_layout.addLayout(controls_layout)

        # Table View for Relation Instances
        self.relation_instances_table = QTableView()
        self.relation_instance_model = RelationInstanceTableModel(self)
        self.relation_instances_table.setModel(self.relation_instance_model)
        self.relation_instances_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.relation_instances_table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.relation_instances_table.setSortingEnabled(True)
        self.relation_instances_table.horizontalHeader().setStretchLastSection(True)
        self.relation_instances_table.doubleClicked.connect(self._view_edit_selected_relation)
        self._main_layout.addWidget(self.relation_instances_table)

        # Action Buttons
        buttons_layout = QHBoxLayout()
        self.new_relation_button = QPushButton("New Relation")
        self.new_relation_button.clicked.connect(self._create_new_relation)
        self.view_edit_button = QPushButton("View/Edit Selected")
        self.view_edit_button.clicked.connect(self._view_edit_selected_relation)
        self.delete_button = QPushButton("Delete Selected")
        self.delete_button.clicked.connect(self._delete_selected_relation)
        self.refresh_button = QPushButton("Refresh List")
        self.refresh_button.clicked.connect(self._load_relation_instances_for_current_type)

        buttons_layout.addWidget(self.new_relation_button)
        buttons_layout.addWidget(self.view_edit_button)
        buttons_layout.addWidget(self.delete_button)
        buttons_layout.addStretch()
        buttons_layout.addWidget(self.refresh_button)
        self._main_layout.addLayout(buttons_layout)

        self._load_relation_types()

    def _schedule_filter_relations(self) -> None:
        self._filter_timer.start()

    def _filter_relations(self) -> None:
        self._load_relation_instances_for_current_type()

    def _load_relation_types(self) -> None:
        self.relation_type_combo.setEnabled(False)
        self._api_thread = ApiClientThread(self.grizabella_client, "list_relation_types")
        self._api_thread.result_ready.connect(self._handle_relation_types_loaded)
        self._api_thread.error_occurred.connect(self._handle_api_error)
        self._api_thread.start()

    @Slot(list)
    def _handle_relation_types_loaded(self, relation_types: list[RelationTypeDefinition]) -> None:
        self.relation_type_combo.setEnabled(True)
        self.relation_types = sorted(relation_types, key=lambda rt: rt.name)
        self.relation_type_combo.clear()
        self.relation_type_combo.addItem("Select Relation Type...", userData=None)
        for rt_def in self.relation_types:
            self.relation_type_combo.addItem(f"{rt_def.name}", userData=rt_def)

        if not self.relation_types:
            QMessageBox.information(self, "No Relation Types", "No relation types found in the database.")
        elif self.relation_type_combo.count() > 1: # More than just placeholder
             self.relation_type_combo.setCurrentIndex(1) # Select the first actual type

    @Slot(int)
    def _on_relation_type_selected(self, index: int) -> None:
        selected_data = self.relation_type_combo.itemData(index)
        if isinstance(selected_data, RelationTypeDefinition):
            self.current_selected_relation_type = selected_data
            self._load_relation_instances_for_current_type()
        else:
            self.current_selected_relation_type = None
            self.relation_instance_model.clear()

    def _load_relation_instances_for_current_type(self) -> None:
        if not self.current_selected_relation_type:
            self.relation_instance_model.clear()
            return

        query_params: dict[str, Any] = {"relation_type_name": self.current_selected_relation_type.name}

        source_id_str = self.source_id_filter_edit.text().strip()
        if source_id_str:
            try:
                query_params["source_object_instance_id"] = uuid.UUID(source_id_str)
            except ValueError:
                QMessageBox.warning(self, "Filter Error", "Invalid Source Object ID UUID format.")
                self.relation_instance_model.clear() # Clear table on bad filter
                return

        target_id_str = self.target_id_filter_edit.text().strip()
        if target_id_str:
            try:
                query_params["target_object_instance_id"] = uuid.UUID(target_id_str)
            except ValueError:
                QMessageBox.warning(self, "Filter Error", "Invalid Target Object ID UUID format.")
                self.relation_instance_model.clear() # Clear table on bad filter
                return

        # Disable UI elements during load
        self.relation_instances_table.setEnabled(False)
        self.refresh_button.setEnabled(False)

        self._api_thread = ApiClientThread(self.grizabella_client, "query_relations", **query_params)
        self._api_thread.result_ready.connect(self._handle_relation_instances_loaded)
        self._api_thread.error_occurred.connect(self._handle_api_error)
        self._api_thread.start()

    @Slot(list)
    def _handle_relation_instances_loaded(self, instances: list[RelationInstance]) -> None:
        self.relation_instances_table.setEnabled(True)
        self.refresh_button.setEnabled(True)
        # Pass the current relation type definition to the model
        current_type_dict = (self.current_selected_relation_type.model_dump()
                             if self.current_selected_relation_type else None)
        self.relation_instance_model.set_relation_instances(instances, current_type_dict)
        if not instances:
            # Avoid too many popups, empty table is clear enough
            pass

    def _create_new_relation(self) -> None:
        if not self.relation_types:
             QMessageBox.warning(self, "Cannot Create Relation", "No relation types available. Please define a relation type first.")
             return

        dialog = RelationInstanceDialog(
            self.grizabella_client,
            self.relation_types,
            parent=self,
            selected_relation_type_name=self.current_selected_relation_type.name if self.current_selected_relation_type else None,
        )
        dialog.relation_saved.connect(self._on_relation_saved)
        dialog.exec()

    def _view_edit_selected_relation(self) -> None:
        selected_indexes = self.relation_instances_table.selectionModel().selectedRows()
        if not selected_indexes:
            QMessageBox.warning(self, "No Selection", "Please select a relation instance to view/edit.")
            return

        selected_row = selected_indexes[0].row()
        instance_to_edit = self.relation_instance_model.get_relation_instance_at_row(selected_row)

        if not instance_to_edit:
            QMessageBox.critical(self, "Error", "Could not retrieve selected relation instance.")
            return

        if not self.relation_types: # Should not happen if we can list instances
             QMessageBox.warning(self, "Error", "Relation types not loaded, cannot edit.")
             return

        dialog = RelationInstanceDialog(
            self.grizabella_client,
            self.relation_types, # Pass all known types
            parent=self,
            instance_to_edit=instance_to_edit,
        )
        dialog.relation_saved.connect(self._on_relation_saved)
        dialog.exec()

    @Slot(object) # RelationInstance
    def _on_relation_saved(self, saved_instance: RelationInstance) -> None:
        # Refresh the list if the saved instance's type matches the currently selected type
        if self.current_selected_relation_type and \
           saved_instance.relation_type_name == self.current_selected_relation_type.name:
            self._load_relation_instances_for_current_type()
        # Optionally, select the newly created/edited item if it's in the list

    def _delete_selected_relation(self) -> None:
        selected_indexes = self.relation_instances_table.selectionModel().selectedRows()
        if not selected_indexes:
            QMessageBox.warning(self, "No Selection", "Please select a relation instance to delete.")
            return

        selected_row = selected_indexes[0].row()
        instance_to_delete = self.relation_instance_model.get_relation_instance_at_row(selected_row)

        if not instance_to_delete:
            QMessageBox.critical(self, "Error", "Could not retrieve selected relation instance for deletion.")
            return

        confirm = QMessageBox.question(
            self,
            "Confirm Delete",
            f"Are you sure you want to delete relation instance '{instance_to_delete.id}'?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )

        if confirm == QMessageBox.StandardButton.Yes:
            self.setEnabled(False) # Disable view during operation
            self._api_thread = ApiClientThread(
                self.grizabella_client,
                "delete_relation",
                relation_id=instance_to_delete.id,
                relation_type_name=instance_to_delete.relation_type_name, # Assuming API needs this
            )
            self._api_thread.result_ready.connect(self._handle_delete_success)
            self._api_thread.error_occurred.connect(self._handle_api_error) # Re-enable on error
            self._api_thread.start()

    @Slot(object) # Result from delete_relation, might be True or some confirmation
    def _handle_delete_success(self, result: Any) -> None:
        self.setEnabled(True)
        QMessageBox.information(self, "Success", "Relation instance deleted successfully.")
        self._load_relation_instances_for_current_type() # Refresh list

    @Slot(str)
    def _handle_api_error(self, error_message: str) -> None:
        self.setEnabled(True) # Re-enable UI
        self.relation_type_combo.setEnabled(True) # Ensure combo is re-enabled
        self.relation_instances_table.setEnabled(True)
        self.refresh_button.setEnabled(True)
        QMessageBox.critical(self, "API Error", f"An API error occurred: {error_message}")

    def refresh_view(self) -> None:
        """Public method to refresh the view, e.g., when tab is selected."""
        self._load_relation_types() # This will trigger subsequent loads
