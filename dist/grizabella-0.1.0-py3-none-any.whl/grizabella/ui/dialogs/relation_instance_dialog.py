import uuid
from typing import Any, Optional

from PySide6.QtCore import QDateTime, Qt, Signal
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDateTimeEdit,
    QDialog,
    QDialogButtonBox,
    QDoubleSpinBox,
    QFormLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QScrollArea,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

from grizabella.api.client import Grizabella  # Corrected import
from grizabella.core.models import (
    PropertyDataType,
    RelationInstance,
    RelationTypeDefinition,
)
from grizabella.ui.threads import ApiClientThread  # Assuming this will be available


class RelationInstanceDialog(QDialog):
    """Dialog for creating or editing a RelationInstance."""

    relation_saved = Signal(object)  # Emits the saved RelationInstance

    def __init__(
        self,
        grizabella_client: Grizabella,  # Corrected type hint
        relation_types: list[RelationTypeDefinition],
        parent: Optional[QWidget] = None,
        instance_to_edit: Optional[RelationInstance] = None,
        selected_relation_type_name: Optional[str] = None,  # Changed from ID to name
    ) -> None:
        super().__init__(parent)
        self.grizabella_client = grizabella_client
        self.instance_to_edit = instance_to_edit
        # Store by name, as RelationTypeDefinition doesn't have a direct 'id' field in models.py
        self.all_relation_types: dict[str, RelationTypeDefinition] = {
            rt.name: rt for rt in relation_types
        }
        self.current_relation_type: Optional[RelationTypeDefinition] = None
        self._saved_instance: Optional[RelationInstance] = (
            None  # Initialize _saved_instance
        )

        self.mode = "edit" if self.instance_to_edit else "create"
        self.setWindowTitle(
            f"{'Edit' if self.mode == 'edit' else 'Create'} Relation Instance",
        )
        self.setMinimumWidth(500)

        self._layout = QVBoxLayout(self)

        # Relation Type Selection
        self.relation_type_combo = QComboBox()
        for rt_def in self.all_relation_types.values():
            # Use rt_def.name as userData since id is not directly on RelationTypeDefinition
            self.relation_type_combo.addItem(f"{rt_def.name}", userData=rt_def.name)
        self.relation_type_combo.currentIndexChanged.connect(
            self._on_relation_type_changed,
        )
        self._layout.addWidget(QLabel("Relation Type:"))
        self._layout.addWidget(self.relation_type_combo)

        # Core Fields
        self.form_layout = QFormLayout()
        self.source_object_id_edit = QLineEdit()
        self.target_object_id_edit = QLineEdit()
        self.weight_spinbox = QDoubleSpinBox()
        self.weight_spinbox.setMinimum(0.0)
        self.weight_spinbox.setMaximum(1.0)  # Assuming weight is between 0 and 1
        self.weight_spinbox.setSingleStep(0.01)
        self.weight_spinbox.setValue(1.0)  # Default weight

        self.form_layout.addRow("Source Object ID (UUID):", self.source_object_id_edit)
        self.form_layout.addRow("Target Object ID (UUID):", self.target_object_id_edit)
        self.form_layout.addRow("Weight:", self.weight_spinbox)

        self._layout.addLayout(self.form_layout)

        # Custom Properties Area
        self.custom_props_scroll_area = QScrollArea()
        self.custom_props_scroll_area.setWidgetResizable(True)
        self.custom_props_widget = QWidget()
        self.custom_props_layout = QFormLayout(self.custom_props_widget)
        self.custom_props_scroll_area.setWidget(self.custom_props_widget)
        self._layout.addWidget(QLabel("Custom Properties:"))
        self._layout.addWidget(self.custom_props_scroll_area)
        self.property_widgets: dict[str, QWidget] = {}

        # Dialog Buttons
        self.button_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel,
        )
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)
        self._layout.addWidget(self.button_box)

        self._api_thread: Optional[ApiClientThread] = None

        # Populate fields if editing or pre-selected type
        if self.instance_to_edit:
            self._populate_for_edit()
        elif selected_relation_type_name:  # Now using name
            idx = self.relation_type_combo.findData(
                selected_relation_type_name,
            )  # Find by name
            if idx != -1:
                self.relation_type_combo.setCurrentIndex(idx)
            elif self.relation_type_combo.count() > 0:
                self.relation_type_combo.setCurrentIndex(0)
        elif self.relation_type_combo.count() > 0:
            self.relation_type_combo.setCurrentIndex(0)  # Select first by default

        self._on_relation_type_changed(
            self.relation_type_combo.currentIndex(),
        )  # Initial population of custom props

    def _populate_for_edit(self) -> None:
        if not self.instance_to_edit:
            return

        # RelationInstance has relation_type_name
        rt_name = self.instance_to_edit.relation_type_name
        idx = self.relation_type_combo.findData(rt_name)
        if idx != -1:
            self.relation_type_combo.setCurrentIndex(idx)
            self.relation_type_combo.setEnabled(
                False,
            )  # Don't allow changing type when editing
        else:
            QMessageBox.warning(
                self, "Error", f"Could not find relation type '{rt_name}' for editing.",
            )
            # Potentially disable fields or close dialog

        self.source_object_id_edit.setText(
            str(self.instance_to_edit.source_object_instance_id),
        )
        self.target_object_id_edit.setText(
            str(self.instance_to_edit.target_object_instance_id),
        )
        self.weight_spinbox.setValue(self.instance_to_edit.weight)

        # Custom properties will be populated by _on_relation_type_changed
        # and then values set here if needed, or in _update_custom_properties_fields

    def _on_relation_type_changed(self, index: int) -> None:
        selected_rt_name = self.relation_type_combo.itemData(
            index,
        )  # This is now the name
        if selected_rt_name:
            self.current_relation_type = self.all_relation_types.get(selected_rt_name)
            self._update_custom_properties_fields()
        else:
            self.current_relation_type = None
            self._clear_custom_properties_fields()

    def _clear_custom_properties_fields(self) -> None:
        for widget in self.property_widgets.values():
            self.custom_props_layout.removeRow(widget)
            widget.deleteLater()
        self.property_widgets.clear()

    def _update_custom_properties_fields(self) -> None:
        self._clear_custom_properties_fields()
        # RelationTypeDefinition has 'properties: List[PropertyDefinition]'
        if not self.current_relation_type or not self.current_relation_type.properties:
            return

        # Iterate through the list of PropertyDefinition objects
        for prop_def in self.current_relation_type.properties:
            prop_name = prop_def.name
            label = prop_def.name
            description = prop_def.description or ""
            # prop_def.data_type is an Enum (PropertyDataType)

            editor: QWidget
            prop_type_enum = prop_def.data_type
            current_value = None
            if self.instance_to_edit and prop_name in self.instance_to_edit.properties:
                current_value = self.instance_to_edit.properties[prop_name]

            if prop_type_enum == PropertyDataType.TEXT:
                editor = QLineEdit()
                if current_value is not None:
                    editor.setText(str(current_value))
            elif prop_type_enum == PropertyDataType.INTEGER:
                editor = QSpinBox()
                editor.setRange(-2147483648, 2147483647)  # Max int range
                if current_value is not None:
                    editor.setValue(int(current_value))
            elif prop_type_enum == PropertyDataType.FLOAT:
                editor = QDoubleSpinBox()
                editor.setRange(-1.7976931348623157e308, 1.7976931348623157e308)
                editor.setDecimals(6)  # Default, can be adjusted
                if current_value is not None:
                    editor.setValue(float(current_value))
            elif prop_type_enum == PropertyDataType.BOOLEAN:
                editor = QCheckBox()
                if current_value is not None:
                    editor.setChecked(bool(current_value))
            elif prop_type_enum == PropertyDataType.DATETIME:
                editor = QDateTimeEdit()
                editor.setCalendarPopup(True)
                editor.setDisplayFormat("yyyy-MM-dd HH:mm:ss")
                if current_value is not None:
                    # Assuming current_value is a datetime object or ISO string
                    if isinstance(current_value, str):
                        qdt = QDateTime.fromString(
                            current_value, "yyyy-MM-ddTHH:mm:ssZ",
                        )  # Example format
                        if not qdt.isValid():  # Try with timezone offset
                            qdt = QDateTime.fromString(
                                current_value, Qt.DateFormat.ISODateWithMs,
                            )
                        if not qdt.isValid():  # Try basic ISO
                            qdt = QDateTime.fromString(
                                current_value, Qt.DateFormat.ISODate,
                            )

                        editor.setDateTime(
                            qdt if qdt.isValid() else QDateTime.currentDateTime(),
                        )
                    elif isinstance(
                        current_value, QDateTime,
                    ):  # If it's already QDateTime
                        editor.setDateTime(current_value)
                    # Add handling for Python datetime objects if necessary
                else:
                    editor.setDateTime(QDateTime.currentDateTime())
            elif prop_type_enum == PropertyDataType.UUID:
                editor = QLineEdit()
                if current_value is not None:
                    editor.setText(str(current_value))
            elif prop_type_enum == PropertyDataType.JSON:
                editor = (
                    QLineEdit()
                )  # For simplicity, JSON as string. Could use QTextEdit.
                if current_value is not None:
                    editor.setText(str(current_value))  # Or json.dumps(current_value)
            elif prop_type_enum == PropertyDataType.BLOB:
                editor = (
                    QLineEdit()
                )  # BLOBs are hard to edit directly, show placeholder or path?
                editor.setPlaceholderText("BLOB data (not directly editable)")
                editor.setReadOnly(True)
                if current_value is not None:
                    editor.setText(
                        f"<BLOB data present, {len(current_value)} bytes>"
                        if isinstance(current_value, bytes)
                        else "<BLOB data>",
                    )

            else:  # Default to QLineEdit for unknown or unhandled types
                editor = QLineEdit()
                if current_value is not None:
                    editor.setText(str(current_value))

            if description:
                editor.setToolTip(description)

            self.custom_props_layout.addRow(f"{label}:", editor)
            self.property_widgets[prop_name] = editor

    def accept(self) -> None:
        if not self.current_relation_type:
            QMessageBox.warning(
                self, "Validation Error", "Please select a relation type.",
            )
            return

        try:
            source_id_str = self.source_object_id_edit.text().strip()
            target_id_str = self.target_object_id_edit.text().strip()

            if not source_id_str:
                QMessageBox.warning(
                    self, "Validation Error", "Source Object ID is required.",
                )
                self.source_object_id_edit.setFocus()
                return
            if not target_id_str:
                QMessageBox.warning(
                    self, "Validation Error", "Target Object ID is required.",
                )
                self.target_object_id_edit.setFocus()
                return

            source_id = uuid.UUID(source_id_str)
            target_id = uuid.UUID(target_id_str)
        except ValueError as e:
            QMessageBox.warning(self, "Validation Error", f"Invalid UUID format: {e}")
            return

        properties = {}
        if self.current_relation_type and self.current_relation_type.properties:
            for prop_def in self.current_relation_type.properties:
                prop_name = prop_def.name
                widget = self.property_widgets.get(prop_name)

                # value_str = widget.text() # This was for QLineEdit only
                prop_type_enum = prop_def.data_type
                parsed_value: Any = None
                has_value = False

                try:
                    if isinstance(widget, QLineEdit):
                        value_str = widget.text().strip()
                        if value_str:
                            has_value = True
                            if prop_type_enum == PropertyDataType.TEXT:
                                parsed_value = value_str
                            elif prop_type_enum == PropertyDataType.UUID:
                                parsed_value = uuid.UUID(value_str)
                            elif prop_type_enum == PropertyDataType.JSON:
                                # For JSON, we might want to parse it here or send as string
                                parsed_value = value_str  # Assuming it's sent as string
                            # BLOB is read-only, so no value extraction here
                    elif isinstance(widget, QSpinBox):
                        has_value = True  # QSpinBox always has a value
                        parsed_value = widget.value()
                    elif isinstance(widget, QDoubleSpinBox):
                        has_value = True
                        parsed_value = widget.value()
                    elif isinstance(widget, QCheckBox):
                        has_value = True  # QCheckBox always has a state
                        parsed_value = widget.isChecked()
                    elif isinstance(widget, QDateTimeEdit):
                        has_value = True
                        # Convert QDateTime to Python datetime object (UTC) or ISO string
                        # For simplicity, let's use ISO string format that Pydantic can parse
                        parsed_value = (
                            widget.dateTime()
                            .toUTC()
                            .toString(Qt.DateFormat.ISODateWithMs)
                        )

                    if has_value:
                        properties[prop_name] = parsed_value
                    elif prop_def.is_nullable:
                        properties[prop_name] = None
                    else:  # Not nullable and no value (or widget type not handled for value extraction)
                        QMessageBox.warning(
                            self,
                            "Validation Error",
                            f"Property '{prop_name}' is required.",
                        )
                        if widget:
                            widget.setFocus()
                        return

                except ValueError as e:  # Catch UUID conversion errors, etc.
                    QMessageBox.warning(
                        self,
                        "Validation Error",
                        f"Invalid value for property '{prop_name}' ({prop_type_enum.value}): {e}",
                    )
                    if widget:
                        widget.setFocus()
                    return

        relation_data = {
            "relation_type_name": self.current_relation_type.name,  # Use name
            "source_object_instance_id": source_id,
            "target_object_instance_id": target_id,
            "weight": self.weight_spinbox.value(),
            "properties": properties,
        }

        if self.instance_to_edit:
            relation_data["id"] = self.instance_to_edit.id
            relation_data["upsert_date"] = (
                self.instance_to_edit.upsert_date
            )  # Preserve original if not changed by backend

        try:
            relation_instance_model = RelationInstance(**relation_data)
        except Exception as e:  # Catch Pydantic validation errors
            QMessageBox.critical(
                self, "Data Error", f"Error creating relation data model: {e}",
            )
            return

        self.button_box.setEnabled(False)
        self._api_thread = ApiClientThread(
            self.grizabella_client, "upsert_relation", relation_instance_model,
        )
        self._api_thread.result_ready.connect(self._handle_save_result)
        self._api_thread.error_occurred.connect(self._handle_api_error)
        self._api_thread.start()

    def _handle_save_result(self, result: RelationInstance) -> None:
        self.button_box.setEnabled(True)
        QMessageBox.information(
            self, "Success", f"Relation instance '{result.id}' saved successfully.",
        )
        self._saved_instance = result  # Store the saved instance
        self.relation_saved.emit(result)
        super().accept()  # Close the dialog

    def _handle_api_error(self, error_message: str) -> None:
        self.button_box.setEnabled(True)
        QMessageBox.critical(
            self, "API Error", f"Failed to save relation instance: {error_message}",
        )

    def get_relation_instance(self) -> Optional[RelationInstance]:
        # This method might not be strictly necessary if we emit a signal with the saved instance
        # and rely on the dialog's exec() result.
        if self.result() == QDialog.DialogCode.Accepted and hasattr(
            self, "_saved_instance",
        ):
            return self._saved_instance
        return None
