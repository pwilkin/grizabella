"""Dialog for creating and editing RelationTypeDefinitions."""

# Standard library imports
from typing import TYPE_CHECKING, Optional

from PySide6.QtCore import Qt, QThread, Signal

# Third-party imports
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from grizabella.core.exceptions import SchemaError

# First-party imports
from grizabella.core.models import (
    ObjectTypeDefinition,
    PropertyDataType,
    PropertyDefinition,
    RelationTypeDefinition,
)

if TYPE_CHECKING:
    from grizabella.api.client import Grizabella  # Corrected type hint


class RelationApiWorker(QThread):
    """Worker thread for RelationTypeDefinition API calls."""

    creation_successful = Signal(RelationTypeDefinition)
    creation_failed = Signal(str)
    update_successful = Signal(RelationTypeDefinition)  # New signal for updates
    update_failed = Signal(str)  # New signal for update failures
    object_types_loaded = Signal(list)  # For loading object types for combos
    object_types_load_failed = Signal(str)

    def __init__(self, client: "Grizabella", parent=None) -> None:  # Corrected type hint
        super().__init__(parent)
        self.client = client
        self.rtd_model: Optional[RelationTypeDefinition] = None
        self.task_type = ""  # "create_rtd", "update_rtd", or "load_ots"

    def run_create_rtd(self, rtd_model: RelationTypeDefinition) -> None:
        """Sets the task to create a RelationTypeDefinition and starts the thread."""
        self.rtd_model = rtd_model
        self.task_type = "create_rtd"
        self.start()

    def run_load_object_types(self) -> None:
        """Sets the task to load object type names and starts the thread."""
        self.task_type = "load_ots"
        self.start()

    def run_update_rtd(self, rtd_model: RelationTypeDefinition) -> None:
        """Sets the task to update a RelationTypeDefinition and starts the thread."""
        self.rtd_model = rtd_model
        self.task_type = "update_rtd"
        self.start()

    def run(self) -> None:
        if not self.client:
            if self.task_type == "create_rtd":
                self.creation_failed.emit("Grizabella client not available.")
            elif self.task_type == "update_rtd":
                self.update_failed.emit("Grizabella client not available.")
            elif self.task_type == "load_ots":
                self.object_types_load_failed.emit("Grizabella client not available.")
            return

        if self.task_type == "create_rtd":
            if not self.rtd_model:
                self.creation_failed.emit(
                    "RelationTypeDefinition model not provided for creation.",
                )
                return
            try:
                # Ensure client has the method before calling
                create_method = getattr(self.client, "create_relation_type", None)
                if callable(create_method):
                    create_method(self.rtd_model)  # This method returns None
                    self.creation_successful.emit(self.rtd_model) # Emit the input model
                else:
                    self.creation_failed.emit(
                        "Client does not support 'create_relation_type'.",
                    )
            except SchemaError as e:
                self.creation_failed.emit(f"Schema Error: {e!s}")
            except Exception as e:
                self.creation_failed.emit(
                    f"An unexpected error occurred during RTD creation: {e!s}",
                )

        elif self.task_type == "update_rtd":
            if not self.rtd_model:
                self.update_failed.emit(
                    "RelationTypeDefinition model not provided for update.",
                )
                return
            try:
                # Assume client has an 'update_relation_type' method
                update_method = getattr(self.client, "update_relation_type", None)
                if callable(update_method):
                    updated_rtd = update_method(self.rtd_model)  # API updates by name
                    self.update_successful.emit(updated_rtd)
                else:
                    self.update_failed.emit(
                        "Client does not support 'update_relation_type'.",
                    )
            except SchemaError as e:
                self.update_failed.emit(f"Schema Error during update: {e!s}")
            except Exception as e:
                self.update_failed.emit(
                    f"An unexpected error occurred during RTD update: {e!s}",
                )

        elif self.task_type == "load_ots":
            try:
                list_method = getattr(self.client, "list_object_types", None)
                if callable(list_method):
                    object_types: list[ObjectTypeDefinition] = list_method() # type: ignore
                    self.object_types_loaded.emit([ot.name for ot in object_types])
                else:
                    self.object_types_load_failed.emit(
                        "Client does not support 'list_object_types'.",
                    )
            except Exception as e:
                self.object_types_load_failed.emit(
                    f"Failed to load object types: {e!s}",
                )


class RelationTypeDialog(QDialog):
    """Dialog for creating or editing a RelationTypeDefinition."""

    relation_type_changed = Signal()

    def __init__(
        self,
        grizabella_client: "Grizabella",
        existing_rtd: Optional[RelationTypeDefinition] = None,
        parent=None,
    ) -> None:  # Corrected type hint
        super().__init__(parent)
        self.grizabella_client = grizabella_client
        self.existing_rtd = existing_rtd
        self.api_worker = RelationApiWorker(self.grizabella_client)
        self.api_worker.object_types_loaded.connect(self._populate_object_type_combos)
        self.api_worker.object_types_load_failed.connect(
            self._handle_object_types_load_failure,
        )

        if self.existing_rtd:
            self.setWindowTitle(f"Edit Relation Type: {self.existing_rtd.name}")
        else:
            self.setWindowTitle("Create New Relation Type")

        self.setMinimumWidth(750)
        self.setMinimumHeight(550)

        self._init_ui()
        self._load_object_types()  # Trigger loading object types for combos

        if self.existing_rtd:
            self._load_existing_data()
        else:
            # Add a default empty property row for new relation types
            self._add_property_row()

    def _init_ui(self) -> None:
        layout = QVBoxLayout(self)

        form_layout = QFormLayout()
        self.name_edit = QLineEdit()
        self.description_edit = QTextEdit()
        self.description_edit.setPlaceholderText(
            "Optional description for the relation type.",
        )
        self.description_edit.setFixedHeight(80)

        self.source_object_type_combo = QComboBox()
        self.target_object_type_combo = QComboBox()

        form_layout.addRow("Name:", self.name_edit)
        form_layout.addRow("Description:", self.description_edit)
        form_layout.addRow("Source Object Type:", self.source_object_type_combo)
        form_layout.addRow("Target Object Type:", self.target_object_type_combo)
        layout.addLayout(form_layout)

        properties_layout = QVBoxLayout()
        properties_label = QLabel("Properties (for the relation itself):")
        properties_layout.addWidget(properties_label)

        self.properties_table = QTableWidget()
        self.properties_table.setColumnCount(
            6,
        )  # Name, Data Type, Nullable, Indexed, Unique, Description
        self.properties_table.setHorizontalHeaderLabels(
            ["Name", "Data Type", "Nullable", "Indexed", "Unique", "Description"],
        )
        header = self.properties_table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)  # Name
        header.setSectionResizeMode(
            1, QHeaderView.ResizeMode.ResizeToContents,
        )  # Data Type
        header.setSectionResizeMode(5, QHeaderView.ResizeMode.Stretch)  # Description
        for i in range(2, 5):  # Nullable, Indexed, Unique
            header.setSectionResizeMode(i, QHeaderView.ResizeMode.ResizeToContents)

        properties_layout.addWidget(self.properties_table)

        prop_buttons_layout = QHBoxLayout()
        self.add_prop_button = QPushButton("Add Property")
        self.remove_prop_button = QPushButton("Remove Selected Property")
        prop_buttons_layout.addWidget(self.add_prop_button)
        prop_buttons_layout.addWidget(self.remove_prop_button)
        prop_buttons_layout.addStretch()
        properties_layout.addLayout(prop_buttons_layout)

        layout.addLayout(properties_layout)

        self.button_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel,
        )
        layout.addWidget(self.button_box)

        self.add_prop_button.clicked.connect(self._add_property_row)
        self.remove_prop_button.clicked.connect(self._remove_property_row)
        self.button_box.accepted.connect(self._on_accept)
        self.button_box.rejected.connect(self.reject)

    def _load_object_types(self) -> None:
        if self.grizabella_client:
            self.source_object_type_combo.setEnabled(False)
            self.target_object_type_combo.setEnabled(False)
            self.source_object_type_combo.addItem("Loading...")
            self.target_object_type_combo.addItem("Loading...")
            self.api_worker.run_load_object_types()
        else:
            QMessageBox.warning(
                self,
                "Client Error",
                "Grizabella client not available to load object types.",
            )
            self.source_object_type_combo.addItem("Error loading")
            self.target_object_type_combo.addItem("Error loading")

    def _populate_object_type_combos(self, object_type_names: list[str]) -> None:
        self.source_object_type_combo.clear()
        self.target_object_type_combo.clear()

        if not object_type_names:
            no_types_msg = "No object types found"
            self.source_object_type_combo.addItem(no_types_msg)
            self.target_object_type_combo.addItem(no_types_msg)
            self.source_object_type_combo.setEnabled(False)
            self.target_object_type_combo.setEnabled(False)
            return

        for name in object_type_names:
            self.source_object_type_combo.addItem(name)
            self.target_object_type_combo.addItem(name)

        self.source_object_type_combo.setEnabled(True)
        self.target_object_type_combo.setEnabled(True)

        if self.existing_rtd:  # Re-select if editing
            if self.existing_rtd.source_object_type_names:
                idx_s = self.source_object_type_combo.findText(
                    self.existing_rtd.source_object_type_names[0],
                )
                if idx_s >= 0:
                    self.source_object_type_combo.setCurrentIndex(idx_s)
            if self.existing_rtd.target_object_type_names:
                idx_t = self.target_object_type_combo.findText(
                    self.existing_rtd.target_object_type_names[0],
                )
                if idx_t >= 0:
                    self.target_object_type_combo.setCurrentIndex(idx_t)

    def _handle_object_types_load_failure(self, error_message: str) -> None:
        QMessageBox.warning(
            self, "Load Error", f"Could not load object types: {error_message}",
        )
        self.source_object_type_combo.clear()
        self.target_object_type_combo.clear()
        self.source_object_type_combo.addItem("Error loading")
        self.target_object_type_combo.addItem("Error loading")
        self.source_object_type_combo.setEnabled(False)
        self.target_object_type_combo.setEnabled(False)

    def _load_existing_data(self) -> None:
        if not self.existing_rtd:
            return

        self.name_edit.setText(self.existing_rtd.name)
        self.name_edit.setReadOnly(
            True,
        )  # Typically, name is not editable after creation
        self.description_edit.setPlainText(self.existing_rtd.description or "")

        # Object types will be selected by _populate_object_type_combos if data is already loaded
        # Or when it finishes loading.

        self.properties_table.setRowCount(0)
        for prop_def in self.existing_rtd.properties:
            self._add_property_row(
                prop_def, read_only_name=True,
            )  # Property names also usually not editable

    def _add_property_row(
        self,
        prop_def: Optional[PropertyDefinition] = None,
        read_only_name: bool = False,
    ) -> None:
        row_position = self.properties_table.rowCount()
        self.properties_table.insertRow(row_position)

        name_edit = QLineEdit(prop_def.name if prop_def else "")
        if read_only_name:
            name_edit.setReadOnly(True)
        self.properties_table.setCellWidget(row_position, 0, name_edit)

        combo_data_type = QComboBox()
        for data_type in PropertyDataType:
            combo_data_type.addItem(data_type.value, data_type)
        if prop_def:
            index = combo_data_type.findData(prop_def.data_type)
            if index >= 0:
                combo_data_type.setCurrentIndex(index)
        self.properties_table.setCellWidget(row_position, 1, combo_data_type)

        # PK is not relevant for relation properties
        # Column indices shift: Nullable (2), Indexed (3), Unique (4), Description (5)

        nullable_check = QCheckBox()
        nullable_check.setChecked(prop_def.is_nullable if prop_def else True)
        self.properties_table.setCellWidget(
            row_position, 2, self._center_widget_in_cell(nullable_check),
        )

        indexed_check = QCheckBox()
        indexed_check.setChecked(prop_def.is_indexed if prop_def else False)
        self.properties_table.setCellWidget(
            row_position, 3, self._center_widget_in_cell(indexed_check),
        )

        unique_check = QCheckBox()
        unique_check.setChecked(prop_def.is_unique if prop_def else False)
        self.properties_table.setCellWidget(
            row_position, 4, self._center_widget_in_cell(unique_check),
        )

        desc_edit = QLineEdit(prop_def.description if prop_def else "")
        desc_edit.setPlaceholderText("Optional property description")
        self.properties_table.setCellWidget(row_position, 5, desc_edit)

    def _center_widget_in_cell(self, widget: QWidget) -> QWidget:
        cell_container_widget = QWidget()
        cell_layout = QHBoxLayout(cell_container_widget)
        cell_layout.addWidget(widget)
        cell_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        cell_layout.setContentsMargins(0, 0, 0, 0)
        return cell_container_widget

    def _remove_property_row(self) -> None:
        current_row = self.properties_table.currentRow()
        if current_row >= 0:
            self.properties_table.removeRow(current_row)
        else:
            QMessageBox.warning(
                self, "Warning", "Please select a property row to remove.",
            )

    def _on_accept(self) -> None:
        rtd_name = self.name_edit.text().strip()
        if not rtd_name:
            QMessageBox.warning(
                self, "Input Error", "Relation Type Name cannot be empty.",
            )
            self.name_edit.setFocus()
            return

        source_ot_name = self.source_object_type_combo.currentText()
        target_ot_name = self.target_object_type_combo.currentText()

        if not source_ot_name or source_ot_name in [
            "Loading...",
            "Error loading",
            "No object types found",
        ]:
            QMessageBox.warning(
                self, "Input Error", "A valid Source Object Type must be selected.",
            )
            self.source_object_type_combo.setFocus()
            return
        if not target_ot_name or target_ot_name in [
            "Loading...",
            "Error loading",
            "No object types found",
        ]:
            QMessageBox.warning(
                self, "Input Error", "A valid Target Object Type must be selected.",
            )
            self.target_object_type_combo.setFocus()
            return

        rtd_description = self.description_edit.toPlainText().strip() or None

        properties = []
        for row in range(self.properties_table.rowCount()):
            name_edit_widget = self.properties_table.cellWidget(row, 0)
            prop_name = (
                name_edit_widget.text().strip()
                if isinstance(name_edit_widget, QLineEdit)
                else ""
            )
            if not prop_name:
                QMessageBox.warning(
                    self,
                    "Input Error",
                    f"Property name in row {row + 1} cannot be empty.",
                )
                if name_edit_widget:
                    name_edit_widget.setFocus()
                return

            data_type_combo_widget = self.properties_table.cellWidget(row, 1)
            prop_data_type_value = (
                data_type_combo_widget.currentData()
                if isinstance(data_type_combo_widget, QComboBox)
                else None
            )

            if not isinstance(prop_data_type_value, PropertyDataType):
                QMessageBox.warning(
                    self, "Input Error", f"Invalid data type selected in row {row + 1}.",
                )
                # Attempt to focus the combo box if possible
                if data_type_combo_widget:
                    data_type_combo_widget.setFocus()
                return
            prop_data_type = prop_data_type_value

            # Nullable (idx 2), Indexed (idx 3), Unique (idx 4)
            nullable_check_container = self.properties_table.cellWidget(row, 2)
            is_nullable = True
            if nullable_check_container:
                nullable_check = nullable_check_container.findChild(QCheckBox)
                if nullable_check:
                    is_nullable = nullable_check.isChecked()

            indexed_check_container = self.properties_table.cellWidget(row, 3)
            is_indexed = False
            if indexed_check_container:
                indexed_check = indexed_check_container.findChild(QCheckBox)
                if indexed_check:
                    is_indexed = indexed_check.isChecked()

            unique_check_container = self.properties_table.cellWidget(row, 4)
            is_unique = False
            if unique_check_container:
                unique_check = unique_check_container.findChild(QCheckBox)
                if unique_check:
                    is_unique = unique_check.isChecked()

            desc_edit_widget = self.properties_table.cellWidget(row, 5)
            prop_description = (
                desc_edit_widget.text().strip() or None
                if isinstance(desc_edit_widget, QLineEdit)
                else None
            )

            properties.append(
                PropertyDefinition(
                    name=prop_name,
                    data_type=prop_data_type,
                    is_primary_key=False,  # PK not applicable for relation properties
                    is_nullable=is_nullable,
                    is_indexed=is_indexed,
                    is_unique=is_unique,
                    description=prop_description,
                ),
            )

        # Unlike Object Types, Relation Types can exist without properties.

        try:
            rtd_model = RelationTypeDefinition(
                name=rtd_name,
                description=rtd_description,
                source_object_type_names=[source_ot_name],  # Model expects a list
                target_object_type_names=[target_ot_name],  # Model expects a list
                properties=properties,
            )
        except ValueError as e:  # Pydantic validation error
            QMessageBox.critical(
                self,
                "Validation Error",
                f"Error creating relation type definition: {e!s}",
            )
            return

        if self.grizabella_client:
            self._set_buttons_enabled(False)

        if self.existing_rtd:
            # Ensure the name (key for update) is from existing_rtd as it's read-only
            rtd_model.name = self.existing_rtd.name
            self.api_worker.update_successful.connect(self._handle_update_success)
            self.api_worker.update_failed.connect(self._handle_update_failure)
            self.api_worker.finished.connect(self._reset_buttons_and_worker)
            self.api_worker.run_update_rtd(rtd_model)
        else:
            # Use the same api_worker instance, but call a method to set its task
            self.api_worker.creation_successful.connect(
                self._handle_creation_success,
            )
            self.api_worker.creation_failed.connect(self._handle_creation_failure)
            self.api_worker.finished.connect(
                self._reset_buttons_and_worker,
            )  # Connect finished only for this task
            self.api_worker.run_create_rtd(rtd_model)
        # This 'else' corresponds to 'if self.grizabella_client:' at line 512
        # It was orphaned by the previous incorrect diff.
        # However, the logic seems to be that if not self.grizabella_client,
        # it's handled earlier. The original structure was:
        # if self.grizabella_client:
        #     self._set_buttons_enabled(False)
        #     if self.existing_rtd:
        #         ...
        #     else: # create new
        #         ...
        # else: # no client
        #     QMessageBox.critical(self, "Error", "Grizabella client not available.")
        #     self._reset_buttons_and_worker()
        # The 'else' for 'if self.grizabella_client' is correctly placed at line 532.
        # The 'else' at line 522 in the previous content was indeed an error from the bad diff.
        # The current structure from line 512 is:
        # if self.grizabella_client:
        #    self._set_buttons_enabled(False)
        #    if self.existing_rtd:
        #        # update logic
        #    else: # not existing_rtd (i.e., create)
        #        # creation logic
        # else: # not self.grizabella_client
        #    QMessageBox.critical(...)
        #    self._reset_buttons_and_worker()
        # This structure is sound. The previous diff incorrectly placed an 'else'
        # and misaligned the creation block.
        # The SEARCH block above reflects the broken state.
        # The REPLACE block fixes the indentation within the 'if self.existing_rtd:' and 'else:' (for create) blocks.

    def _set_buttons_enabled(self, enabled: bool) -> None:
        ok_button = self.button_box.button(QDialogButtonBox.StandardButton.Ok)
        if ok_button:
            ok_button.setEnabled(enabled)
        cancel_button = self.button_box.button(QDialogButtonBox.StandardButton.Cancel)
        if cancel_button:
            cancel_button.setEnabled(enabled)

    def _handle_creation_success(self, created_rtd: RelationTypeDefinition) -> None:
        QMessageBox.information(
            self, "Success", f"Relation Type '{created_rtd.name}' created successfully.",
        )
        self.relation_type_changed.emit()
        self.accept()

    def _handle_creation_failure(self, error_message: str) -> None:
        QMessageBox.critical(self, "Creation Failed", error_message)
        # Do not reset buttons here, _reset_buttons_and_worker will be called on finished

    def _handle_update_success(self, updated_rtd: RelationTypeDefinition) -> None:
        QMessageBox.information(
            self, "Success", f"Relation Type '{updated_rtd.name}' updated successfully.",
        )
        self.relation_type_changed.emit()
        self.accept()

    def _handle_update_failure(self, error_message: str) -> None:
        QMessageBox.critical(self, "Update Failed", error_message)
        # Do not reset buttons here, _reset_buttons_and_worker will be called on finished

    def _reset_buttons_and_worker(self) -> None:
        self._set_buttons_enabled(True)
        # Disconnect signals specific to the task to avoid multiple connections
        # if the dialog is reused or accept is called multiple times.
        # The object_types_loaded signals are connected once in __init__.
        try:
            self.api_worker.creation_successful.disconnect(
                self._handle_creation_success,
            )
        except RuntimeError:
            pass  # Signal not connected
        try:
            self.api_worker.creation_failed.disconnect(self._handle_creation_failure)
        except RuntimeError:
            pass  # Signal not connected
        try:
            self.api_worker.update_successful.disconnect(self._handle_update_success)
        except RuntimeError:
            pass  # Signal not connected
        try:
            self.api_worker.update_failed.disconnect(self._handle_update_failure)
        except RuntimeError:
            pass  # Signal not connected
        try:
            self.api_worker.finished.disconnect(self._reset_buttons_and_worker)
        except RuntimeError:
            pass  # Signal not connected

    def closeEvent(self, event) -> None:
        # Ensure worker is stopped if dialog is closed, though QThread usually handles this
        if self.api_worker and self.api_worker.isRunning():
            # self.api_worker.quit() # Request interruption
            # self.api_worker.wait(1000) # Wait a bit
            pass  # QThread is usually managed well by Python's GC when parented or if it finishes
        super().closeEvent(event)


# For testing the dialog independently
if __name__ == "__main__":
    import sys  # Standard library

    from PySide6.QtWidgets import QApplication  # Third-party

    # First-party imports
    from grizabella.api.client import Grizabella
    from grizabella.core.models import RelationInstance

    # Mock GrizabellaClient for standalone testing
    class MockGrizabellaClient(Grizabella):  # Inherit from Grizabella
        """Mock Grizabella client for testing RelationTypeDialog."""

        def __init__(self) -> None:
            # Call super init as Grizabella requires db_name_or_path
            super().__init__(db_name_or_path="mock_relation_type_dialog_db")

        def create_relation_type(
            self, relation_type_def: RelationTypeDefinition,
        ) -> None:  # Corrected signature
            # import time; time.sleep(1) # Simulate delay
            if relation_type_def.name == "ErrorTest":
                msg = "This is a mock schema error for ErrorTest."
                raise SchemaError(msg)

        # update_relation_type is not in the base Grizabella client.
        # The RelationApiWorker uses getattr, so it will correctly report
        # "Client does not support 'update_relation_type'" if this mock is used for edit testing.

        def get_relation(
            self, from_object_id: str, to_object_id: str, relation_type_name: str,
        ) -> list[RelationInstance]: # Match base class signature
            """Mocked get_relation."""
            return [] # Return empty list

        def delete_relation( # Corrected signature
            self, relation_type_name: str, relation_id: str, # Match Grizabella.delete_relation
        ) -> bool:
            """Mocked delete_relation."""
            return False

        def list_object_types(self) -> list[ObjectTypeDefinition]:
            # import time; time.sleep(0.5)
            return [
                ObjectTypeDefinition(
                    name="Document",
                    properties=[
                        PropertyDefinition(
                            name="title", data_type=PropertyDataType.TEXT,
                        ),
                    ],
                ),
                ObjectTypeDefinition(
                    name="Person",
                    properties=[
                        PropertyDefinition(name="name", data_type=PropertyDataType.TEXT),
                    ],
                ),
                ObjectTypeDefinition(
                    name="Event",
                    properties=[
                        PropertyDefinition(
                            name="date", data_type=PropertyDataType.DATETIME,
                        ),
                    ],
                ),
            ]

    app = QApplication(sys.argv)
    mock_client = MockGrizabellaClient()

    dialog_new = RelationTypeDialog(grizabella_client=mock_client)
    if dialog_new.exec():
        pass
    else:
        pass

    # Test with existing data (simplified, edit not fully implemented)
    # existing_prop = PropertyDefinition(name="role", data_type=PropertyDataType.TEXT)
    # mock_rtd = RelationTypeDefinition(
    #     name="HAS_AUTHOR",
    #     description="Indicates authorship.",
    #     source_object_type_names=["Document"],
    #     target_object_type_names=["Person"],
    #     properties=[existing_prop]
    # )
    # dialog_edit = RelationTypeDialog(grizabella_client=mock_client, existing_rtd=mock_rtd)
    # if dialog_edit.exec():
    #     print("Dialog accepted (Edit RTD).")
    # else:
    #     print("Dialog cancelled (Edit RTD).")

    sys.exit(app.exec())
