"""QThread worker for executing Grizabella API client calls asynchronously."""

from typing import Callable  # Moved typing import first

from PySide6.QtCore import QThread, Signal

from grizabella.api.client import Grizabella  # Corrected import


class ApiClientThread(QThread):
    """A QThread to execute Grizabella API calls asynchronously."""

    result_ready = Signal(object)  # Emits the result of the API call
    error_occurred = Signal(str)  # Emits an error message if the call fails

    def __init__(
        self, client: Grizabella, method_name: str, *args, **kwargs,
    ) -> None:  # Corrected type hint
        super().__init__()
        self.client = client
        self.method_name = method_name
        self.args = args
        self.kwargs = kwargs
        self._method_to_call: Callable = getattr(self.client, self.method_name)

    def run(self) -> None:
        """Executes the API call."""
        try:
            if not self._method_to_call:
                msg = f"Method '{self.method_name}' not found in Grizabella client."
                raise AttributeError(
                    msg,
                )

            result = self._method_to_call(*self.args, **self.kwargs)
            self.result_ready.emit(result)
        except Exception as e:
            self.error_occurred.emit(str(e))
