"""Pydantic models for Grizabella Complex Query Engine."""
from typing import Any, Literal, Optional
from uuid import UUID

from pydantic import BaseModel, Field

# Assuming ObjectInstance will be imported from grizabella.core.models
# This will create a circular import if ObjectInstance also imports from query_models.
# If that's the case, we might need to use forward references (e.g., 'ObjectInstance')
# or move some models around. For now, let's try a direct import.
from grizabella.core.models import ObjectInstance


class RelationalFilter(BaseModel):
    """Defines a filter condition based on an object's property value.

    This model is used within `QueryComponent` and `GraphTraversalClause`
    to specify conditions for filtering objects based on their properties.
    It allows for various comparison operators against a given value.

    Attributes:
        property_name (str): The name of the property on which to apply the filter.
            This must match a property defined in the relevant `ObjectTypeDefinition`.
        operator (Literal): The comparison operator to use. Supported operators
            include "==", "!=", ">", "<", ">=", "<=", "LIKE", "IN", "CONTAINS",
            "STARTSWITH", and "ENDSWITH".
        value (Any): The value to compare the property against. The type of this
            value should be compatible with the data type of the specified property.
            For "IN" operator, this should be a list of values.

    """

    property_name: str = Field(
        ...,
        description="Name of the property to filter on.",
    )
    operator: Literal[
        "==", "!=", ">", "<", ">=", "<=", "LIKE", "IN",
        "CONTAINS", "STARTSWITH", "ENDSWITH", # Added common operators
    ] = Field(
        ...,
        description="The comparison operator.",
    )
    value: Any = Field(
        ...,
        description="The value to compare against.",
    )


class EmbeddingSearchClause(BaseModel):
    """Defines a search based on embedding similarity.

    This clause is used within a `QueryComponent` to find objects that are
    semantically similar to a given query vector, based on pre-computed
    embeddings.

    Attributes:
        embedding_definition_name (str): The name of the `EmbeddingDefinition`
            to use for this search. This definition specifies the model and
            source property used to generate the embeddings being searched.
        similar_to_payload (List[float]): The embedding vector to find
            similarities against. This vector should have the same dimensions
            as specified in the `EmbeddingDefinition`.
        threshold (Optional[float]): An optional similarity score threshold.
            Only results with a similarity score greater than or equal to this
            threshold will be returned. If None, no threshold is applied.
        limit (int): The maximum number of similar items to retrieve and
            consider from this clause. Defaults to 10.

    """

    embedding_definition_name: str = Field(
        ...,
        description="Name of the EmbeddingDefinition to use for this search.",
    )
    similar_to_payload: list[float] = Field(
        ...,
        description="The embedding vector to find similarities against.",
    )
    # similar_to_object_id: Optional[UUID] = Field(
    #     default=None,
    #     description="Alternatively, specify an object ID whose embedding should be used as the query vector."
    # )
    # similar_to_object_type_name: Optional[str] = Field(
    #     default=None,
    #     description="Required if similar_to_object_id is specified."
    # )
    threshold: Optional[float] = Field(
        default=None,
        description="Optional similarity threshold. Only results above this score are returned.",
    )
    limit: int = Field(
        default=10,
        description="Maximum number of similar items to consider from this clause.",
    )
    is_l2_distance: bool = Field(
        default=False,
        description="If True, indicates that the threshold is for L2 distance (smaller is better) "
                    "and the QueryEngine should not convert distance to cosine similarity."
    )

    # @field_validator('similar_to_object_id')
    # def check_similar_to_object_details(cls, v, values):
    #     if v and not values.get('similar_to_object_type_name'):
    #         raise ValueError(
    #             "similar_to_object_type_name is required if similar_to_object_id is provided."
    #         )
    #     if values.get('similar_to_payload') and v:
    #         raise ValueError(
    #             "Cannot specify both similar_to_payload and similar_to_object_id."
    #         )
    #     if not values.get('similar_to_payload') and not v:
    #         raise ValueError(
    #             "Must specify either similar_to_payload or similar_to_object_id."
    #         )
    #     return v


class GraphTraversalClause(BaseModel):
    """Defines a graph traversal condition from a source object set.

    This clause is used within a `QueryComponent` to navigate relationships
    in the graph database. It specifies the type of relation to follow,
    the direction of traversal, and conditions on the target objects.

    Attributes:
        relation_type_name (str): The name of the `RelationTypeDefinition`
            that defines the type of relationship to traverse.
        direction (Literal["outgoing", "incoming"]): The direction of the
            traversal from the current set of source objects. "outgoing" means
            following relations where the current objects are the source;
            "incoming" means following relations where they are the target.
            Defaults to "outgoing".
        target_object_type_name (str): The expected `ObjectTypeDefinition` name
            of the target node(s) at the end of the traversal.
        target_object_id (Optional[UUID]): An optional specific ID of a target
            object. If provided, the traversal will only consider paths leading
            to this specific object.
        target_object_properties (Optional[List[RelationalFilter]]): Optional
            list of `RelationalFilter`s to apply to the properties of the
            target object(s) found by the traversal.

    """

    relation_type_name: str = Field(
        ...,
        description="Name of the RelationTypeDefinition to traverse.",
    )
    direction: Literal["outgoing", "incoming"] = Field(
        default="outgoing",
        description="Direction of the traversal from the source object.",
    )
    target_object_type_name: str = Field(
        ...,
        description="Expected ObjectTypeDefinition name of the target node(s).",
    )
    target_object_id: Optional[UUID] = Field(
        default=None,
        description="Optional specific ID of the target object.",
    )
    target_object_properties: Optional[list[RelationalFilter]] = Field(
        default=None,
        description="Optional filters to apply to the properties of the target object(s).",
    )
    # Future enhancements:
    # min_hops: int = Field(default=1, description="Minimum number of hops for the traversal.")
    # max_hops: int = Field(default=1, description="Maximum number of hops for the traversal.")
    # relation_properties: Optional[List[RelationalFilter]] = Field(
    #     default=None,
    #     description="Optional filters to apply to the properties of the relation itself."
    # )


class QueryComponent(BaseModel):
    """Defines a single logical block of query conditions targeting a primary object type.

    A `QueryComponent` groups various types of search and filter conditions
    that apply to a specific `ObjectTypeDefinition`. All conditions
    (relational filters, embedding searches, graph traversals) specified
    within a single component are implicitly ANDed together. The results
    from these conditions are intersected to produce a set of matching
    `ObjectInstance`s of the `object_type_name`.

    Attributes:
        object_type_name (str): The primary `ObjectTypeDefinition` name that
            this component targets. The query starts by considering objects
            of this type.
        relational_filters (Optional[List[RelationalFilter]]): A list of
            `RelationalFilter`s to apply to the properties of objects of
            `object_type_name`. Typically processed by a relational database layer.
        embedding_searches (Optional[List[EmbeddingSearchClause]]): A list of
            `EmbeddingSearchClause`s to perform semantic similarity searches.
            Typically processed by a vector database layer.
        graph_traversals (Optional[List[GraphTraversalClause]]): A list of
            `GraphTraversalClause`s to navigate relationships from or to
            objects of `object_type_name`. Typically processed by a graph
            database layer.

    """

    object_type_name: str = Field(
        ...,
        description="The primary ObjectTypeDefinition name this component targets.",
    )
    relational_filters: Optional[list[RelationalFilter]] = Field(
        default=None,
        description="List of relational filters to apply (SQLite).",
    )
    embedding_searches: Optional[list[EmbeddingSearchClause]] = Field(
        default=None,
        description="List of embedding similarity searches to apply (LanceDB).",
    )
    graph_traversals: Optional[list[GraphTraversalClause]] = Field(
        default=None,
        description="List of graph traversals to apply (Kuzu).",
    )


class ComplexQuery(BaseModel):
    """Represents a complex query that can span multiple database layers and object types.

    A `ComplexQuery` is composed of one or more `QueryComponent`s.
    Currently, the results from these components are combined using a logical
    AND operation, meaning an `ObjectInstance` must satisfy the conditions
    of all components (if it's the target type of multiple components, or
    related to objects satisfying other components) to be included in the
    final result set.

    Future enhancements may include OR logic between components, explicit
    return property selection, and overall result limits/offsets.

    Attributes:
        description (Optional[str]): An optional user-defined description or
            name for this complex query, for easier identification or logging.
        components (List[QueryComponent]): A list of `QueryComponent`s that
            make up the query. The results from these components are currently
            intersected (ANDed).

    """

    description: Optional[str] = Field(
        default=None,
        description="Optional user-defined description for the query.",
    )
    components: list[QueryComponent] = Field(
        ...,
        description="List of query components. Results from components are currently ANDed.",
    )
    # Future:
    # logical_operator: Literal["AND", "OR"] = Field(
    #     default="AND",
    #     description="How to combine the results of multiple components."
    # )
    # return_properties: Optional[List[str]] = Field(
    #     default=None,
    #     description="Specify which properties of the final objects to return. If None, all are returned."
    # )
    # limit: Optional[int] = Field(default=None, description="Overall limit for the final result set.")
    # offset: Optional[int] = Field(default=0, description="Overall offset for the final result set.")


class QueryResult(BaseModel):
    """Represents the result of a complex query execution.

    This model encapsulates the `ObjectInstance`s that match the criteria
    of a `ComplexQuery`, along with any errors that may have occurred during
    the query planning or execution process.

    Attributes:
        object_instances (List[ObjectInstance]): A list of `ObjectInstance`s
            that satisfy all conditions of the `ComplexQuery`.
        errors (Optional[List[str]]): A list of error messages encountered
            during the execution of the query. If the query was successful,
            this will be None or an empty list.

    """

    object_instances: list[ObjectInstance] = Field(
        default_factory=list,
        description="List of ObjectInstances that match the complex query.",
    )
    errors: Optional[list[str]] = Field(
        default=None,
        description="List of errors encountered during query execution, if any.",
    )
    # Future:
    # execution_time_ms: Optional[float] = None
    # result_count: Optional[int] = None # Could be len(object_instances) but explicit might be useful
    # metadata: Optional[Dict[str, Any]] = None # For additional execution details
